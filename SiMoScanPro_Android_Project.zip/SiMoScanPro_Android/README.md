# SiMo Scan Pro — Android starter (v0.1.0)

This is a real Android Studio source project scaffold, not a finished CamScanner-equivalent app.

## Included in this starter
- Kotlin Android application structure.
- CameraX live preview and full-quality still capture to the app cache.
- OpenCV four-point perspective transform helper (`PerspectiveProcessor`). The caller must supply detected/selected corners in TL, TR, BR, BL order.
- Basic grayscale, contrast and black/white bitmap filters (`ImageEnhancement`).
- ML Kit Latin-script OCR adapter (`OcrService`).

## Not yet implemented
- Automatic document edge detection and automatic corner tracking in the camera preview.
- Interactive four-corner editor and automatic skew/rotation estimation.
- Shadow removal, background cleanup, adaptive thresholding tuned for Arabic documents, denoising and book-curvature correction.
- Arabic OCR. The included ML Kit recognizer is Latin-script only; Arabic needs a separately selected and tested OCR engine/model.
- Document library, multi-page scanning, PDF create/merge/split/compress/password, Word/Excel export, signatures, annotations, cloud sync and subscriptions.
- Production QA, accessibility, localization, privacy/security review and store release configuration.

## Build
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (17 recommended for this Android Gradle Plugin line).
2. Open this folder in Android Studio and allow Gradle sync to download dependencies.
3. Build > Make Project, then Run on a physical Android device or emulator with camera support.

The current execution environment did not have Android SDK or Gradle installed, so an APK has **not** been built or tested here. Dependency resolution and compilation must be verified in Android Studio.

## Package
`com.simo.scanpro`
