package com.simo.scanpro

import android.Manifest
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private lateinit var previewView: PreviewView
    private lateinit var imageView: ImageView
    private lateinit var status: TextView
    private lateinit var pagesStrip: LinearLayout
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private val pages = mutableListOf<File>()
    private var selectedIndex = -1
    private var showingCamera = true

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else toast("لازم تسمح باستخدام الكاميرا علشان نصور المستند")
    }
    private val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri -> copyUriToPages(uri) }
        if (pages.isNotEmpty()) showPage(pages.lastIndex)
        refreshPages()
        setStatus("تم إضافة ${uris.size} صورة")
    }
    private val createPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        loadSavedPages()
        if (pages.isNotEmpty()) showPage(pages.lastIndex) else requestCamera()
    }

    private fun buildInterface() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF0F4F6.toInt())
        }
        val header = TextView(this).apply {
            text = "SiMo Scan Pro\nماسح ضوئي احترافي للمستندات"
            textSize = 21f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(20, 22, 20, 20)
            setBackgroundColor(0xFF10283D.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(header)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(6, 8, 6, 8)
        }
        addButton(actions, "تصوير", true) { if (showingCamera && imageCapture != null) capturePhoto() else requestCamera() }
        addButton(actions, "اختيار صور", false) { pickImages.launch("image/*") }
        addButton(actions, "حفظ PDF", false) {
            if (pages.isEmpty()) toast("صور المستند الأول") else createPdf.launch("SiMo-Scan-${timestamp()}.pdf")
        }
        root.addView(actions)

        val frame = android.widget.FrameLayout(this).apply {
            setBackgroundColor(0xFF172633.toInt())
        }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
            setBackgroundColor(0xFF172633.toInt())
        }
        frame.addView(previewView, android.widget.FrameLayout.LayoutParams(-1, -1))
        frame.addView(imageView, android.widget.FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        val editActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 4)
        }
        addButton(editActions, "تدوير 90°", false) { rotateSelected() }
        addButton(editActions, "أبيض وأسود", false) { applyGrayscale() }
        addButton(editActions, "الأصل", false) { selectedIndex.takeIf { it in pages.indices }?.let { showPage(it) } }
        root.addView(editActions)

        val label = TextView(this).apply {
            text = "صفحات المستند"
            textSize = 14f
            setTextColor(0xFF10283D.toInt())
            setPadding(14, 5, 14, 2)
        }
        root.addView(label)
        val horizontal = HorizontalScrollView(this)
        pagesStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 8) }
        horizontal.addView(pagesStrip)
        root.addView(horizontal)
        status = TextView(this).apply {
            text = "جاهز"
            textSize = 12f
            setTextColor(0xFF526675.toInt())
            setPadding(14, 5, 14, 12)
        }
        root.addView(status)
        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, title: String, primary: Boolean, action: () -> Unit) {
        val button = Button(this).apply {
            text = title
            textSize = 12f
            isAllCaps = false
            setTextColor(if (primary) 0xFFFFFFFF.toInt() else 0xFF10283D.toInt())
            setBackgroundColor(if (primary) 0xFF159C96.toInt() else 0xFFE0EAEE.toInt())
            setOnClickListener { action() }
            setPadding(5, 3, 5, 3)
        }
        val lp = LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3, 0, 3, 0) }
        parent.addView(button, lp)
    }

    private fun requestCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        showingCamera = true
        previewView.visibility = View.VISIBLE
        imageView.visibility = View.GONE
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                showCameraCaptureButton()
                setStatus("الكاميرا جاهزة — وجّهها نحو الورقة واضغط تصوير")
            } catch (e: Exception) {
                setStatus("مش قادر أشغل الكاميرا: ${e.localizedMessage ?: "خطأ غير معروف"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showCameraCaptureButton() {
        // Capture is also available from the main action row by tapping the preview twice.
        previewView.setOnClickListener { capturePhoto() }
        setStatus("اضغط على معاينة الكاميرا لالتقاط الصورة")
    }

    private fun capturePhoto() {
        val capture = imageCapture ?: run { toast("الكاميرا لسه مش جاهزة"); return }
        val file = File(filesDir, "scan_${timestamp()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                pages.add(file)
                showPage(pages.lastIndex)
                refreshPages()
                setStatus("اتصورت الصفحة بنجاح")
            }
            override fun onError(exception: ImageCaptureException) {
                setStatus("فشل التصوير: ${exception.message}")
            }
        })
    }

    private fun copyUriToPages(uri: Uri) {
        try {
            val file = File(filesDir, "import_${timestamp()}_${pages.size}.jpg")
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
            if (file.exists() && file.length() > 0) pages.add(file) else file.delete()
        } catch (e: Exception) { toast("مش قادر أفتح الصورة دي") }
    }

    private fun showPage(index: Int) {
        if (index !in pages.indices) return
        selectedIndex = index
        showingCamera = false
        cameraProvider?.unbindAll()
        previewView.visibility = View.GONE
        imageView.visibility = View.VISIBLE
        val bitmap = BitmapFactory.decodeFile(pages[index].absolutePath)
        imageView.setImageBitmap(bitmap)
        setStatus("الصفحة ${index + 1} من ${pages.size}")
        refreshPages()
    }

    private fun rotateSelected() {
        val file = selectedFile() ?: return
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(90f) }, true)
        saveBitmap(rotated, file)
        showPage(selectedIndex)
        setStatus("تم تدوير الصفحة")
    }

    private fun applyGrayscale() {
        val file = selectedFile() ?: return
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(output)
        val paint = Paint().apply { colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply { setSaturation(0f) }) }
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        saveBitmap(output, file)
        showPage(selectedIndex)
        setStatus("تم تحويل الصفحة لأبيض وأسود")
    }

    private fun saveBitmap(bitmap: Bitmap, file: File) {
        FileOutputStream(file, false).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }

    private fun selectedFile(): File? = pages.getOrNull(selectedIndex).also { if (it == null) toast("اختار صفحة الأول") }

    private fun refreshPages() {
        pagesStrip.removeAllViews()
        pages.forEachIndexed { index, file ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(6, 4, 6, 4)
                setBackgroundColor(if (index == selectedIndex) 0xFFD2EFEC.toInt() else 0xFFE8EEF1.toInt())
                setOnClickListener { showPage(index) }
            }
            val thumb = ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(file.absolutePath)?.let { Bitmap.createScaledBitmap(it, 90, 110, true) })
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            item.addView(thumb, LinearLayout.LayoutParams(76, 76))
            item.addView(TextView(this).apply { text = "صفحة ${index + 1}"; textSize = 11f; setTextColor(0xFF10283D.toInt()) })
            pagesStrip.addView(item, LinearLayout.LayoutParams(90, 104).apply { setMargins(4, 0, 4, 0) })
        }
    }

    private fun loadSavedPages() {
        val found = filesDir.listFiles()?.filter { it.isFile && (it.name.startsWith("scan_") || it.name.startsWith("import_")) && it.extension.lowercase() == "jpg" }
            ?.sortedBy { it.name }.orEmpty()
        pages.addAll(found)
        refreshPages()
    }

    private fun exportPdf(uri: Uri) {
        try {
            val pdf = PdfDocument()
            pages.forEachIndexed { index, file ->
                val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return@forEachIndexed
                val scale = min(595f / bitmap.width, 842f / bitmap.height)
                val width = max(1, (bitmap.width * scale).toInt())
                val height = max(1, (bitmap.height * scale).toInt())
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, index + 1).create()
                val page = pdf.startPage(pageInfo)
                val left = (595 - width) / 2f
                val top = (842 - height) / 2f
                page.canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, width, height, true), left, top, Paint(Paint.FILTER_BITMAP_FLAG))
                pdf.finishPage(page)
            }
            contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
            pdf.close()
            setStatus("اتحفظ ملف PDF بنجاح")
        } catch (e: Exception) { setStatus("حصلت مشكلة أثناء حفظ PDF: ${e.localizedMessage}") }
    }

    private fun timestamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
    private fun setStatus(message: String) { status.text = message }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
