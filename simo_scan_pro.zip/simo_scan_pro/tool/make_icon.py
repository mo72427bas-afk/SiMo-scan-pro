#!/usr/bin/env python3
"""Generates the SiMo Scan Pro launcher icon (original artwork, Pillow only)."""
import pathlib
from PIL import Image, ImageDraw, ImageFilter

S = 2048  # supersampled canvas
root = pathlib.Path(__file__).resolve().parent.parent
out = root / "assets" / "branding"
out.mkdir(parents=True, exist_ok=True)

def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def build(rounded=True):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    # gradient background
    bg = Image.new("RGB", (S, S))
    px = bg.load()
    top, bot = (58, 108, 255), (9, 22, 66)
    for y in range(S):
        c = lerp(top, bot, y / S)
        for x in range(S):
            px[x, y] = c
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * 0.22) if rounded else 0, fill=255)
    img.paste(bg, (0, 0), mask)
    d = ImageDraw.Draw(img)

    # sheet with folded corner
    x0, y0, x1, y1 = int(S * .30), int(S * .20), int(S * .70), int(S * .78)
    fold = int(S * .12)
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).polygon([(x0 + 30, y0 + 40), (x1 - fold + 30, y0 + 40), (x1 + 30, y0 + fold + 40), (x1 + 30, y1 + 40), (x0 + 30, y1 + 40)], fill=(0, 0, 20, 120))
    shadow = shadow.filter(ImageFilter.GaussianBlur(40))
    img = Image.alpha_composite(img, shadow)
    d = ImageDraw.Draw(img)
    d.polygon([(x0, y0), (x1 - fold, y0), (x1, y0 + fold), (x1, y1), (x0, y1)], fill=(255, 255, 255, 255))
    d.polygon([(x1 - fold, y0), (x1, y0 + fold), (x1 - fold, y0 + fold)], fill=(205, 218, 245, 255))
    # text lines
    ly = y0 + int(S * .12)
    for i, wfrac in enumerate([.78, .62, .78, .5]):
        d.rounded_rectangle((x0 + int(S * .04), ly, x0 + int(S * .04) + int((x1 - x0 - S * .08) * wfrac), ly + int(S * .022)),
                            radius=int(S * .011), fill=(150, 168, 215, 255))
        ly += int(S * .07)

    # gold scan beam with glow
    by = int(S * .56)
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).rounded_rectangle((int(S * .17), by - 30, int(S * .83), by + 30), radius=30, fill=(242, 176, 30, 200))
    glow = glow.filter(ImageFilter.GaussianBlur(45))
    img = Image.alpha_composite(img, glow)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((int(S * .17), by - 17, int(S * .83), by + 17), radius=17, fill=(255, 196, 46, 255))

    # corner brackets
    gold = (255, 196, 46, 255)
    m, L, t = int(S * .13), int(S * .12), int(S * .028)
    a, b = m + int(S * .03), S - m - int(S * .03)
    for (cx, cy, sx, sy) in [(a, a, 1, 1), (b, a, -1, 1), (a, b, 1, -1), (b, b, -1, -1)]:
        d.rounded_rectangle((min(cx, cx + sx * L), min(cy, cy + sy * t), max(cx, cx + sx * L), max(cy, cy + sy * t)), radius=t // 2, fill=gold)
        d.rounded_rectangle((min(cx, cx + sx * t), min(cy, cy + sy * L), max(cx, cx + sx * t), max(cy, cy + sy * L)), radius=t // 2, fill=gold)
    return img

master = build().resize((1024, 1024), Image.LANCZOS)
master.save(out / "icon_1024.png")
sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
for name, px_ in sizes.items():
    d_ = out / "android" / f"mipmap-{name}"
    d_.mkdir(parents=True, exist_ok=True)
    master.resize((px_, px_), Image.LANCZOS).save(d_ / "ic_launcher.png")
print("icon written to", out)
