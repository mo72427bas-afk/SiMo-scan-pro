#!/usr/bin/env bash
# Generates android/ and ios/ folders around the committed Dart sources,
# applies permissions and downloads OCR language data.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ] || [ ! -d ios ]; then
  mkdir -p .bootstrap_backup
  cp -r lib test pubspec.yaml analysis_options.yaml .bootstrap_backup/ 2>/dev/null || true
  flutter create --platforms=android,ios --org com.simo --project-name simo_scan_pro .
  # `flutter create` may rewrite these; restore ours.
  rm -rf lib test
  cp -r .bootstrap_backup/lib lib
  cp -r .bootstrap_backup/test test
  cp .bootstrap_backup/pubspec.yaml pubspec.yaml
  cp .bootstrap_backup/analysis_options.yaml analysis_options.yaml
  rm -rf .bootstrap_backup
fi

python3 tool/apply_platform_config.py
bash tool/fetch_tessdata.sh
flutter pub get
