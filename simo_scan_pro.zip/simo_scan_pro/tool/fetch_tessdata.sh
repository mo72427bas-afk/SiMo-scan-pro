#!/usr/bin/env bash
# Downloads Arabic + English Tesseract models (tessdata_fast, ~ 5 MB total).
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p assets/tessdata
for lang in ara eng; do
  f="assets/tessdata/${lang}.traineddata"
  if [ ! -s "$f" ]; then
    curl -fL -o "$f" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/${lang}.traineddata"
  fi
done
ls -lh assets/tessdata
