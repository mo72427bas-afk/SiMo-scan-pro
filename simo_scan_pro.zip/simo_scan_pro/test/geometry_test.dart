import 'package:flutter_test/flutter_test.dart';
import 'package:simo_scan_pro/imaging/geometry.dart';
import 'package:simo_scan_pro/imaging/rgb_image.dart';

void main() {
  test('Quad.fromUnordered orders corners', () {
    final q = Quad.fromUnordered(const [
      Pt(0.9, 0.9),
      Pt(0.1, 0.1),
      Pt(0.1, 0.9),
      Pt(0.9, 0.1),
    ]);
    expect(q.tl.x, 0.1);
    expect(q.tl.y, 0.1);
    expect(q.tr.x, 0.9);
    expect(q.tr.y, 0.1);
    expect(q.br.x, 0.9);
    expect(q.br.y, 0.9);
    expect(q.bl.x, 0.1);
    expect(q.bl.y, 0.9);
  });

  test('homography maps source corners to destination corners', () {
    const from = [Pt(0, 0), Pt(10, 0), Pt(10, 10), Pt(0, 10)];
    const to = [Pt(2, 1), Pt(12, 3), Pt(11, 14), Pt(1, 12)];
    final h = computeHomography(from, to)!;
    for (var i = 0; i < 4; i++) {
      final x = from[i].x, y = from[i].y;
      final den = h[6] * x + h[7] * y + 1;
      expect((h[0] * x + h[1] * y + h[2]) / den, closeTo(to[i].x, 1e-6));
      expect((h[3] * x + h[4] * y + h[5]) / den, closeTo(to[i].y, 1e-6));
    }
  });

  test('warp of a full-frame quad keeps size', () {
    final src = RgbImage.blank(80, 60, fill: 200);
    final out = warpPerspective(src, Quad.full());
    expect(out.width, 80);
    expect(out.height, 60);
    expect(out.data[0], 200);
  });
}
