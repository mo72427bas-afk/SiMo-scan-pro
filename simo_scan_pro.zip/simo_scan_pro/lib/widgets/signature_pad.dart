import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../l10n/strings.dart';

class SignatureResult {
  SignatureResult(this.png, this.aspect);
  final Uint8List png;
  final double aspect;
}

/// Dialog to draw a signature; returns a transparent, tightly cropped PNG.
Future<SignatureResult?> showSignaturePad(BuildContext context) {
  return showDialog<SignatureResult>(
    context: context,
    builder: (_) => const _SignatureDialog(),
  );
}

class _SignatureDialog extends StatefulWidget {
  const _SignatureDialog();
  @override
  State<_SignatureDialog> createState() => _SignatureDialogState();
}

class _SignatureDialogState extends State<_SignatureDialog> {
  final List<List<Offset>> _strokes = [];
  Color _color = const Color(0xFF0B1B8A);
  static const _w = 3.5;

  Future<SignatureResult?> _export() async {
    final pts = _strokes.expand((s) => s).toList();
    if (pts.isEmpty) return null;
    var minX = pts.first.dx, maxX = pts.first.dx;
    var minY = pts.first.dy, maxY = pts.first.dy;
    for (final p in pts) {
      if (p.dx < minX) minX = p.dx;
      if (p.dx > maxX) maxX = p.dx;
      if (p.dy < minY) minY = p.dy;
      if (p.dy > maxY) maxY = p.dy;
    }
    const pad = 12.0, scale = 3.0;
    final w = (maxX - minX + pad * 2).clamp(40.0, 4000.0);
    final h = (maxY - minY + pad * 2).clamp(40.0, 4000.0);
    final rec = ui.PictureRecorder();
    final c = Canvas(rec)..scale(scale);
    final paint = Paint()
      ..color = _color
      ..strokeWidth = _w
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    for (final s in _strokes) {
      final path = Path()..moveTo(s.first.dx - minX + pad, s.first.dy - minY + pad);
      for (final p in s.skip(1)) {
        path.lineTo(p.dx - minX + pad, p.dy - minY + pad);
      }
      if (s.length == 1) {
        c.drawCircle(Offset(s.first.dx - minX + pad, s.first.dy - minY + pad),
            _w / 2, paint..style = PaintingStyle.fill);
        paint.style = PaintingStyle.stroke;
      } else {
        c.drawPath(path, paint);
      }
    }
    final image =
        await rec.endRecording().toImage((w * scale).round(), (h * scale).round());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    return SignatureResult(data!.buffer.asUint8List(), w / h);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(context.tr('drawSignature')),
      content: SizedBox(
        width: 340,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 190,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.black26),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: GestureDetector(
                  onPanStart: (d) =>
                      setState(() => _strokes.add([d.localPosition])),
                  onPanUpdate: (d) =>
                      setState(() => _strokes.last.add(d.localPosition)),
                  child: CustomPaint(
                    painter: _PadPainter(_strokes, _color, _w),
                    size: Size.infinite,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                for (final col in const [
                  Color(0xFF0B1B8A),
                  Colors.black,
                  Color(0xFFB3261E),
                ])
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: GestureDetector(
                      onTap: () => setState(() => _color = col),
                      child: CircleAvatar(
                        radius: 13,
                        backgroundColor: col,
                        child: _color == col
                            ? const Icon(Icons.check, size: 14, color: Colors.white)
                            : null,
                      ),
                    ),
                  ),
                const Spacer(),
                TextButton(
                  onPressed: () => setState(_strokes.clear),
                  child: Text(context.tr('clear')),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(context.tr('cancel'))),
        FilledButton(
          onPressed: () async {
            final r = await _export();
            if (context.mounted) Navigator.pop(context, r);
          },
          child: Text(context.tr('done')),
        ),
      ],
    );
  }
}

class _PadPainter extends CustomPainter {
  _PadPainter(this.strokes, this.color, this.w);
  final List<List<Offset>> strokes;
  final Color color;
  final double w;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    for (final s in strokes) {
      if (s.length == 1) {
        canvas.drawCircle(s.first, w / 2, paint..style = PaintingStyle.fill);
        paint.style = PaintingStyle.stroke;
        continue;
      }
      final path = Path()..moveTo(s.first.dx, s.first.dy);
      for (final p in s.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_PadPainter old) => true;
}
