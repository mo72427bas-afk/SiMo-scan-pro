import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../imaging/geometry.dart';

/// Image with a draggable quad: 4 corner handles + 4 edge handles
/// (8 control points) and a magnifier while dragging.
class CropCanvas extends StatefulWidget {
  const CropCanvas({
    super.key,
    required this.image,
    required this.aspect,
    required this.quad,
    required this.onChanged,
    this.onStart,
  });

  final Uint8List image;
  final double aspect; // width / height of the image
  final Quad quad;
  final ValueChanged<Quad> onChanged;
  final VoidCallback? onStart; // called when a drag begins (for undo)

  @override
  State<CropCanvas> createState() => _CropCanvasState();
}

class _CropCanvasState extends State<CropCanvas> {
  int? _active; // 0-3 corners, 4-7 edges (top,right,bottom,left)

  static const _hit = 44.0;

  Pt _edgeMid(Quad q, int e) => switch (e) {
        0 => q.tl.lerp(q.tr, .5),
        1 => q.tr.lerp(q.br, .5),
        2 => q.br.lerp(q.bl, .5),
        _ => q.bl.lerp(q.tl, .5),
      };

  Pt _clamp(Pt p) => Pt(p.x.clamp(0.0, 1.0), p.y.clamp(0.0, 1.0));

  void _drag(int handle, Offset delta, Size size) {
    final d = Pt(delta.dx / size.width, delta.dy / size.height);
    var q = widget.quad;
    if (handle < 4) {
      q = q.withPoint(handle, _clamp(q.points[handle] + d));
    } else {
      final e = handle - 4;
      final a = e, b = (e + 1) % 4;
      final pts = q.points;
      pts[a] = _clamp(pts[a] + d);
      pts[b] = _clamp(pts[b] + d);
      q = Quad(pts[0], pts[1], pts[2], pts[3]);
    }
    widget.onChanged(q);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      var w = c.maxWidth, h = w / widget.aspect;
      if (h > c.maxHeight) {
        h = c.maxHeight;
        w = h * widget.aspect;
      }
      final size = Size(w, h);
      final q = widget.quad;

      final handles = <Widget>[];
      for (var i = 0; i < 8; i++) {
        final p = i < 4 ? q.points[i] : _edgeMid(q, i - 4);
        final px = p.x * w, py = p.y * h;
        handles.add(Positioned(
          left: px - _hit / 2,
          top: py - _hit / 2,
          width: _hit,
          height: _hit,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanStart: (_) {
              widget.onStart?.call();
              setState(() => _active = i);
            },
            onPanUpdate: (d) => _drag(i, d.delta, size),
            onPanEnd: (_) => setState(() => _active = null),
            onPanCancel: () => setState(() => _active = null),
            child: Center(
              child: Container(
                width: i < 4 ? 22 : 16,
                height: i < 4 ? 22 : 16,
                decoration: BoxDecoration(
                  color: i < 4 ? AppColors.gold : Colors.white,
                  shape: i < 4 ? BoxShape.circle : BoxShape.rectangle,
                  borderRadius: i < 4 ? null : BorderRadius.circular(4),
                  border: Border.all(color: AppColors.blue, width: 2),
                ),
              ),
            ),
          ),
        ));
      }

      Widget? loupe;
      if (_active != null) {
        final i = _active!;
        final p = i < 4 ? q.points[i] : _edgeMid(q, i - 4);
        const ls = 110.0;
        var lx = p.x * w - ls / 2;
        var ly = p.y * h - ls - 50;
        if (ly < 0) ly = p.y * h + 50;
        lx = lx.clamp(0.0, w - ls);
        final fy = ly < p.y * h ? ls / 2 + 50 : -(ls / 2 + 50);
        loupe = Positioned(
          left: lx,
          top: ly,
          child: IgnorePointer(
            child: RawMagnifier(
              size: const Size(ls, ls),
              magnificationScale: 2.5,
              focalPointOffset: Offset(p.x * w - (lx + ls / 2), fy),
              decoration: const MagnifierDecoration(
                shape: CircleBorder(
                    side: BorderSide(color: AppColors.gold, width: 3)),
              ),
            ),
          ),
        );
      }

      return Center(
        child: SizedBox(
          width: w,
          height: h,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(
                child: Image.memory(widget.image,
                    fit: BoxFit.fill, gaplessPlayback: true, cacheWidth: 1400),
              ),
              Positioned.fill(
                child: CustomPaint(painter: _QuadPainter(q)),
              ),
              ...handles,
              if (loupe != null) loupe,
            ],
          ),
        ),
      );
    });
  }
}

class _QuadPainter extends CustomPainter {
  _QuadPainter(this.q);
  final Quad q;

  @override
  void paint(Canvas canvas, Size s) {
    final path = Path()
      ..moveTo(q.tl.x * s.width, q.tl.y * s.height)
      ..lineTo(q.tr.x * s.width, q.tr.y * s.height)
      ..lineTo(q.br.x * s.width, q.br.y * s.height)
      ..lineTo(q.bl.x * s.width, q.bl.y * s.height)
      ..close();
    canvas.drawPath(
        path, Paint()..color = AppColors.blue.withValues(alpha: .18));
    canvas.drawPath(
      path,
      Paint()
        ..color = AppColors.gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
  }

  @override
  bool shouldRepaint(_QuadPainter old) => old.q != q;
}
