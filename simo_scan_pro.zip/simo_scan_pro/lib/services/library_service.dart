import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/models.dart';

/// Stores folders / documents / pages as JSON + image files inside the
/// app's private documents directory.
class LibraryService extends ChangeNotifier {
  static const _uuid = Uuid();

  late Directory _root;
  final List<FolderModel> folders = [];
  final List<DocModel> docs = [];

  static String newId() => _uuid.v4();

  Future<void> init() async {
    final base = await getApplicationDocumentsDirectory();
    _root = Directory(p.join(base.path, 'simo_scan'));
    await _root.create(recursive: true);
    final f = File(p.join(_root.path, 'library.json'));
    if (await f.exists()) {
      try {
        final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
        folders.addAll((j['folders'] as List)
            .map((e) => FolderModel.fromJson(e as Map<String, dynamic>)));
        docs.addAll((j['docs'] as List)
            .map((e) => DocModel.fromJson(e as Map<String, dynamic>)));
      } catch (e) {
        debugPrint('library load failed: $e');
      }
    }
  }

  Future<void> _save() async {
    final f = File(p.join(_root.path, 'library.json'));
    await f.writeAsString(jsonEncode({
      'folders': folders.map((e) => e.toJson()).toList(),
      'docs': docs.map((e) => e.toJson()).toList(),
    }));
    notifyListeners();
  }

  Directory docDir(String docId) {
    final d = Directory(p.join(_root.path, 'files', docId));
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  File fileOf(String docId, String name) => File(p.join(docDir(docId).path, name));

  DocModel? doc(String id) {
    for (final d in docs) {
      if (d.id == id) return d;
    }
    return null;
  }

  // ---- documents ------------------------------------------------------
  Future<DocModel> createDoc(String name, {String? folderId}) async {
    final d = DocModel(id: newId(), name: name, folderId: folderId);
    docs.insert(0, d);
    await _save();
    return d;
  }

  Future<void> addPages(String docId, List<PageModel> pages) async {
    doc(docId)?.pages.addAll(pages);
    await _save();
  }

  Future<void> commit() => _save();

  Future<void> renameDoc(String id, String name) async {
    doc(id)?.name = name;
    await _save();
  }

  Future<void> moveDoc(String id, String? folderId) async {
    doc(id)?.folderId = folderId;
    await _save();
  }

  Future<void> deleteDoc(String id) async {
    docs.removeWhere((d) => d.id == id);
    final dir = Directory(p.join(_root.path, 'files', id));
    if (await dir.exists()) await dir.delete(recursive: true);
    await _save();
  }

  Future<void> removePage(String docId, int index) async {
    final d = doc(docId);
    if (d == null) return;
    final page = d.pages.removeAt(index);
    for (final n in [page.origFile, page.procFile]) {
      final f = fileOf(docId, n);
      if (await f.exists()) await f.delete();
    }
    await _save();
  }

  Future<void> reorderPages(String docId, int oldIndex, int newIndex) async {
    final d = doc(docId);
    if (d == null) return;
    if (newIndex > oldIndex) newIndex -= 1;
    d.pages.insert(newIndex, d.pages.removeAt(oldIndex));
    await _save();
  }

  // ---- folders --------------------------------------------------------
  Future<void> createFolder(String name, {String? parentId}) async {
    folders.add(FolderModel(id: newId(), name: name, parentId: parentId));
    await _save();
  }

  Future<void> renameFolder(String id, String name) async {
    for (final f in folders) {
      if (f.id == id) f.name = name;
    }
    await _save();
  }

  Future<void> deleteFolder(String id) async {
    // Documents move back to the root; sub-folders are deleted recursively.
    final ids = <String>{id};
    var grew = true;
    while (grew) {
      grew = false;
      for (final f in folders) {
        if (f.parentId != null && ids.contains(f.parentId) && ids.add(f.id)) {
          grew = true;
        }
      }
    }
    folders.removeWhere((f) => ids.contains(f.id));
    for (final d in docs) {
      if (ids.contains(d.folderId)) d.folderId = null;
    }
    await _save();
  }
}
