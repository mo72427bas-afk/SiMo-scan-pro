import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Arabic + English OCR using Tesseract (`ara+eng`).
///
/// NOTE: Google ML Kit text recognition does NOT support Arabic, which is why
/// Tesseract is used. Language data lives in assets/tessdata (see
/// tool/fetch_tessdata.sh).
class OcrService {
  static Future<String> recognize(Uint8List jpg, {String lang = 'ara+eng'}) async {
    final tmp = await getTemporaryDirectory();
    final f = File(p.join(tmp.path, 'ocr_input.jpg'));
    await f.writeAsBytes(jpg, flush: true);
    final text = await FlutterTesseractOcr.extractText(
      f.path,
      language: lang,
      args: {'psm': '4', 'preserve_interword_spaces': '1'},
    );
    return text.trim();
  }
}
