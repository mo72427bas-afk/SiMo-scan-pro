import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

class PdfPageImage {
  PdfPageImage(this.jpeg, this.width, this.height);
  final Uint8List jpeg;
  final int width;
  final int height;
}

/// Small self-contained PDF writer: one JPEG per page, optional password
/// protection (standard security handler, RC4 128-bit, revision 3).
///
/// The algorithm is a line-by-line port of a Python reference that was
/// verified with qpdf / pikepdf (correct password opens, wrong one fails).
class PdfWriter {
  static final Uint8List _pad = Uint8List.fromList(const [
    0x28, 0xBF, 0x4E, 0x5E, 0x4E, 0x75, 0x8A, 0x41, 0x64, 0x00, 0x4E, 0x56, //
    0xFF, 0xFA, 0x01, 0x08, 0x2E, 0x2E, 0x00, 0xB6, 0xD0, 0x68, 0x3E, 0x80,
    0x2F, 0x0C, 0xA9, 0xFE, 0x64, 0x53, 0x69, 0x7A,
  ]);

  /// Only plain ASCII passwords are portable across PDF readers.
  static bool isValidPassword(String p) =>
      RegExp(r'^[\x20-\x7E]+$').hasMatch(p);

  static Uint8List _md5(List<int> b) => Uint8List.fromList(md5.convert(b).bytes);

  static Uint8List _cat(List<List<int>> parts) {
    final b = BytesBuilder(copy: false);
    for (final p in parts) {
      b.add(p);
    }
    return b.toBytes();
  }

  static Uint8List _rc4(Uint8List key, Uint8List data) {
    final s = List<int>.generate(256, (i) => i);
    var j = 0;
    for (var i = 0; i < 256; i++) {
      j = (j + s[i] + key[i % key.length]) & 255;
      final t = s[i];
      s[i] = s[j];
      s[j] = t;
    }
    final out = Uint8List(data.length);
    var a = 0, b = 0;
    for (var k = 0; k < data.length; k++) {
      a = (a + 1) & 255;
      b = (b + s[a]) & 255;
      final t = s[a];
      s[a] = s[b];
      s[b] = t;
      out[k] = data[k] ^ s[(s[a] + s[b]) & 255];
    }
    return out;
  }

  static Uint8List _padPw(List<int> pw) =>
      Uint8List.fromList(_cat([pw, _pad]).sublist(0, 32));

  static Uint8List _xorKey(Uint8List key, int i) =>
      Uint8List.fromList(key.map((b) => b ^ i).toList());

  static Uint8List _ownerEntry(List<int> user, List<int> owner) {
    var h = _md5(_padPw(owner));
    for (var i = 0; i < 50; i++) {
      h = _md5(h);
    }
    final key = Uint8List.fromList(h.sublist(0, 16));
    var r = _rc4(key, _padPw(user));
    for (var i = 1; i < 20; i++) {
      r = _rc4(_xorKey(key, i), r);
    }
    return r;
  }

  static Uint8List _fileKey(List<int> user, Uint8List o, Uint8List fid) {
    // P = -4 (all permissions) as unsigned little-endian 32 bit.
    const p = [0xFC, 0xFF, 0xFF, 0xFF];
    var h = _md5(_cat([_padPw(user), o, p, fid]));
    for (var i = 0; i < 50; i++) {
      h = _md5(h.sublist(0, 16));
    }
    return Uint8List.fromList(h.sublist(0, 16));
  }

  static Uint8List _userEntry(Uint8List key, Uint8List fid) {
    var r = _rc4(key, _md5(_cat([_pad, fid])));
    for (var i = 1; i < 20; i++) {
      r = _rc4(_xorKey(key, i), r);
    }
    return _cat([r, Uint8List(16)]);
  }

  static Uint8List _objKey(Uint8List key, int num) => Uint8List.fromList(
        _md5(_cat([
          key,
          [num & 255, (num >> 8) & 255, (num >> 16) & 255, 0, 0],
        ])).sublist(0, 16),
      );

  static String _hex(List<int> b) =>
      b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();

  static Uint8List _ascii(String s) => Uint8List.fromList(ascii.encode(s));

  /// Builds the PDF. [password] null/empty = no protection.
  static Uint8List build(List<PdfPageImage> pages, {String? password}) {
    final enc = password != null && password.isNotEmpty;
    final rnd = Random.secure();
    final fid = Uint8List.fromList(List<int>.generate(16, (_) => rnd.nextInt(256)));

    late Uint8List key, o, u;
    if (enc) {
      final pw = latin1.encode(password);
      o = _ownerEntry(pw, pw);
      key = _fileKey(pw, o, fid);
      u = _userEntry(key, fid);
    }

    final n = pages.length;
    final bodies = <int, Uint8List Function(int)>{};

    Uint8List stream(String dict, Uint8List data, int num) {
      final d = enc ? _rc4(_objKey(key, num), data) : data;
      return _cat([
        _ascii('<< $dict /Length ${d.length} >>\nstream\n'),
        d,
        _ascii('\nendstream'),
      ]);
    }

    final kids = [for (var i = 0; i < n; i++) '${3 + 3 * i} 0 R'].join(' ');
    bodies[1] = (_) => _ascii('<< /Type /Catalog /Pages 2 0 R >>');
    bodies[2] = (_) => _ascii('<< /Type /Pages /Kids [$kids] /Count $n >>');

    for (var i = 0; i < n; i++) {
      final pg = pages[i];
      const pw = 595.0;
      final ph = pw * pg.height / pg.width;
      final pn = 3 + 3 * i, cn = 4 + 3 * i, im = 5 + 3 * i;
      final w = pw.toStringAsFixed(2), h = ph.toStringAsFixed(2);
      bodies[pn] = (_) => _ascii(
          '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $w $h] '
          '/Resources << /XObject << /Im0 $im 0 R >> >> /Contents $cn 0 R >>');
      bodies[cn] = (num) =>
          stream('', _ascii('q $w 0 0 $h 0 0 cm /Im0 Do Q'), num);
      bodies[im] = (num) => stream(
            '/Type /XObject /Subtype /Image /Width ${pg.width} '
            '/Height ${pg.height} /ColorSpace /DeviceRGB '
            '/BitsPerComponent 8 /Filter /DCTDecode',
            pg.jpeg,
            num,
          );
    }

    final encNum = 3 + 3 * n;
    if (enc) {
      bodies[encNum] = (_) => _ascii(
          '<< /Filter /Standard /V 2 /R 3 /Length 128 /P -4 '
          '/O <${_hex(o)}> /U <${_hex(u)}> >>');
    }
    final total = enc ? encNum : 2 + 3 * n;

    final out = BytesBuilder(copy: false);
    out.add(_ascii('%PDF-1.4\n'));
    out.add(const [0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A]);
    final offsets = List<int>.filled(total + 1, 0);
    for (var num = 1; num <= total; num++) {
      offsets[num] = out.length;
      out.add(_ascii('$num 0 obj\n'));
      out.add(bodies[num]!(num));
      out.add(_ascii('\nendobj\n'));
    }
    final xref = out.length;
    final sb = StringBuffer('xref\n0 ${total + 1}\n0000000000 65535 f \n');
    for (var num = 1; num <= total; num++) {
      sb.write('${offsets[num].toString().padLeft(10, '0')} 00000 n \n');
    }
    sb.write('trailer\n<< /Size ${total + 1} /Root 1 0 R ');
    if (enc) sb.write('/Encrypt $encNum 0 R ');
    sb.write('/ID [<${_hex(fid)}> <${_hex(fid)}>] >>\nstartxref\n$xref\n%%EOF\n');
    out.add(_ascii(sb.toString()));
    return out.toBytes();
  }
}
