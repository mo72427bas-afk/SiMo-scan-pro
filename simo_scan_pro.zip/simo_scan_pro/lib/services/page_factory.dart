import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../imaging/filters.dart';
import '../imaging/pipeline.dart';
import '../models/models.dart';
import 'library_service.dart';

/// Turns raw image bytes into stored pages (original + processed file).
class PageFactory {
  PageFactory(this.lib);
  final LibraryService lib;

  static const previewSide = 1600;
  static const finalSide = 2600;

  Future<Uint8List> render(
    Uint8List orig, {
    required List<double>? quad,
    required ScanFilter filter,
    required bool shadow,
    required bool fingers,
    required int rotation,
    bool flatten = false,
    int maxSide = finalSide,
    int quality = 90,
  }) =>
      compute(renderPageJob, {
        'bytes': orig,
        'quad': quad,
        'filter': filter.index,
        'shadow': shadow,
        'fingers': fingers,
        'flatten': flatten,
        'rotation': rotation,
        'maxSide': maxSide,
        'quality': quality,
      });

  Future<PageModel> _store(
    String docId,
    Uint8List origJpg,
    int w,
    int h,
    List<double>? quad, {
    bool flatten = false,
  }) async {
    final id = LibraryService.newId();
    final origName = 'orig_$id.jpg';
    final procName = 'proc_$id.jpg';
    final page = PageModel(
      id: id,
      origFile: origName,
      procFile: procName,
      origW: w,
      origH: h,
      quad: quad,
      flatten: flatten,
    );
    await lib.fileOf(docId, origName).writeAsBytes(origJpg, flush: true);
    final proc = await render(
      origJpg,
      quad: quad,
      filter: page.filter,
      shadow: page.shadow,
      fingers: page.fingers,
      flatten: flatten,
      rotation: 0,
    );
    await lib.fileOf(docId, procName).writeAsBytes(proc, flush: true);
    return page;
  }

  /// Camera capture or gallery image (auto-detects the document quad).
  Future<PageModel> fromImage(String docId, Uint8List raw) async {
    final r = await compute(importJob, {'bytes': raw});
    return _store(docId, r['bytes'] as Uint8List, r['w'] as int,
        r['h'] as int, (r['quad'] as List).map((e) => (e as num).toDouble()).toList());
  }

  /// Two facing book pages from one photo.
  Future<List<PageModel>> fromBook(String docId, Uint8List raw,
      {required bool rtl}) async {
    final parts = await compute(bookJob, {'bytes': raw, 'rtl': rtl});
    final pages = <PageModel>[];
    for (final r in parts) {
      pages.add(await _store(docId, r['bytes'] as Uint8List, r['w'] as int,
          r['h'] as int, (r['quad'] as List).map((e) => (e as num).toDouble()).toList(),
          flatten: true));
    }
    return pages;
  }

  /// Front + back of an ID card on one A4 page.
  Future<PageModel> fromIdCard(String docId, Uint8List front, Uint8List back) async {
    Future<Uint8List> prep(Uint8List raw) async {
      final r = await compute(importJob, {'bytes': raw});
      return render(
        r['bytes'] as Uint8List,
        quad: (r['quad'] as List).map((e) => (e as num).toDouble()).toList(),
        filter: ScanFilter.magic,
        shadow: true,
        fingers: false,
        rotation: 0,
        maxSide: 1600,
      );
    }

    final f = await prep(front);
    final b = await prep(back);
    final sheet = await compute(idCardJob, {'front': f, 'back': b});
    return _store(docId, sheet, 1654, 2339, null);
  }
}
