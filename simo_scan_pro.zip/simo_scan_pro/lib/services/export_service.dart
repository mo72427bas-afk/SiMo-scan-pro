import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../imaging/pipeline.dart';
import '../models/models.dart';
import 'library_service.dart';
import 'ocr_service.dart';

enum PdfQuality { low, medium, high }

class ExportService {
  ExportService(this.lib);
  final LibraryService lib;

  static String _safe(String n) =>
      n.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim().isEmpty
          ? 'scan'
          : n.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();

  Future<Directory> _outDir() async {
    final t = await getTemporaryDirectory();
    final d = Directory(p.join(t.path, 'exports'));
    await d.create(recursive: true);
    return d;
  }

  Future<List<Uint8List>> _pageBytes(DocModel d) async => [
        for (final pg in d.pages) await lib.fileOf(d.id, pg.procFile).readAsBytes()
      ];

  // ---- PDF (compression + optional password) --------------------------
  Future<File> toPdf(DocModel d,
      {PdfQuality quality = PdfQuality.high, String? password}) async {
    final (maxSide, q) = switch (quality) {
      PdfQuality.low => (1000, 55),
      PdfQuality.medium => (1600, 75),
      PdfQuality.high => (2600, 90),
    };
    final raw = await _pageBytes(d);
    final jpgs = <Uint8List>[];
    for (final b in raw) {
      jpgs.add(await compute(
          recompressJob, {'bytes': b, 'maxSide': maxSide, 'quality': q}));
    }
    final pdfBytes = await compute(_buildPdf, {
      'pages': jpgs,
      'password': password,
    });
    final f = File(p.join((await _outDir()).path, '${_safe(d.name)}.pdf'));
    await f.writeAsBytes(pdfBytes, flush: true);
    return f;
  }

  // ---- JPG files ---------------------------------------------------------
  Future<List<File>> toJpgs(DocModel d) async {
    final out = await _outDir();
    final files = <File>[];
    for (var i = 0; i < d.pages.length; i++) {
      final f = File(p.join(out.path, '${_safe(d.name)}_${i + 1}.jpg'));
      await f.writeAsBytes(await lib.fileOf(d.id, d.pages[i].procFile).readAsBytes());
      files.add(f);
    }
    return files;
  }

  // ---- TXT / DOCX via OCR ----------------------------------------------
  Future<String> _ocrAll(DocModel d, {void Function(int, int)? onProgress}) async {
    final buf = StringBuffer();
    for (var i = 0; i < d.pages.length; i++) {
      onProgress?.call(i + 1, d.pages.length);
      final pg = d.pages[i];
      pg.ocrText ??= await OcrService.recognize(
          await lib.fileOf(d.id, pg.procFile).readAsBytes());
      buf.writeln(pg.ocrText);
      if (i < d.pages.length - 1) buf.writeln('\n');
    }
    await lib.commit();
    return buf.toString();
  }

  Future<File> toTxt(DocModel d, {void Function(int, int)? onProgress}) async {
    final text = await _ocrAll(d, onProgress: onProgress);
    final f = File(p.join((await _outDir()).path, '${_safe(d.name)}.txt'));
    await f.writeAsString(text, flush: true);
    return f;
  }

  Future<File> toDocx(DocModel d, {void Function(int, int)? onProgress}) async {
    final text = await _ocrAll(d, onProgress: onProgress);
    final bytes = buildDocx(text);
    final f = File(p.join((await _outDir()).path, '${_safe(d.name)}.docx'));
    await f.writeAsBytes(bytes, flush: true);
    return f;
  }

  /// Minimal .docx writer; Arabic lines are marked right-to-left.
  @visibleForTesting
  static List<int> buildDocx(String text) {
    String esc(String s) => s
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;');
    final arabic = RegExp(r'[؀-ۿ]');
    final body = StringBuffer();
    for (final line in const LineSplitter().convert(text)) {
      final rtl = arabic.hasMatch(line);
      body.write('<w:p>');
      if (rtl) body.write('<w:pPr><w:bidi/><w:jc w:val="left"/></w:pPr>');
      body.write('<w:r>');
      if (rtl) body.write('<w:rPr><w:rtl/></w:rPr>');
      body.write('<w:t xml:space="preserve">${esc(line)}</w:t></w:r></w:p>');
    }
    const ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
    final document =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document $ns><w:body>$body<w:sectPr/></w:body></w:document>';
    const contentTypes =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>';
    const rels =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';

    final archive = Archive();
    void add(String name, String content) {
      final b = utf8.encode(content);
      archive.addFile(ArchiveFile(name, b.length, b));
    }

    add('[Content_Types].xml', contentTypes);
    add('_rels/.rels', rels);
    add('word/document.xml', document);
    return ZipEncoder().encode(archive)!;
  }
}

Future<Uint8List> _buildPdf(Map<String, dynamic> m) async {
  final doc = pw.Document(compress: true);
  final password = m['password'] as String?;
  if (password != null && password.isNotEmpty) {
    // Password protection (RC4). If your `pdf` package version exposes a
    // different constructor, adjust this single call.
    doc.document.encryption = PdfEncryption.rc4(
      doc.document,
      userPassword: password,
      ownerPassword: password,
    );
  }
  for (final b in (m['pages'] as List).cast<Uint8List>()) {
    final image = pw.MemoryImage(b);
    final w = image.width ?? 1000, h = image.height ?? 1400;
    const pageW = 595.0; // A4 width in points
    final pageH = pageW * h / w;
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat(pageW, pageH),
      margin: pw.EdgeInsets.zero,
      build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
    ));
  }
  return doc.save();
}
