import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  Locale? locale; // null = follow system
  bool bookRtl = false;

  Future<void> init() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final l = sp.getString('locale');
      if (l != null) locale = Locale(l);
      bookRtl = sp.getBool('bookRtl') ?? false;
    } catch (_) {}
  }

  Future<void> setLocale(Locale l) async {
    locale = l;
    notifyListeners();
    try {
      (await SharedPreferences.getInstance()).setString('locale', l.languageCode);
    } catch (_) {}
  }

  Future<void> setBookRtl(bool v) async {
    bookRtl = v;
    notifyListeners();
    try {
      (await SharedPreferences.getInstance()).setBool('bookRtl', v);
    } catch (_) {}
  }
}
