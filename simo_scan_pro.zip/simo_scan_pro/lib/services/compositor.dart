import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../imaging/rgb_image.dart';

/// Eraser stroke; points and width are normalised to the image width/height.
class EraseStroke {
  EraseStroke(this.points, this.width);
  final List<Offset> points;
  final double width; // fraction of image width
}

/// A signature/stamp image placed on the page (normalised rect).
class Placement {
  Placement(this.png, this.aspect, {this.cx = .5, this.cy = .8, this.w = .35});
  final Uint8List png;
  final double aspect; // width / height of the PNG
  double cx, cy, w; // centre + width as fractions of the page width
  double startW = .35; // width at the start of a pinch gesture
}

class OverlayData {
  final List<EraseStroke> strokes = [];
  final List<Placement> placements = [];
  String watermark = '';
  bool get isEmpty => strokes.isEmpty && placements.isEmpty && watermark.isEmpty;
}

class Compositor {
  /// Draws eraser strokes, signatures and watermark onto the page and
  /// returns a JPEG at the page's own resolution.
  static Future<Uint8List> bake(Uint8List pageJpg, OverlayData o,
      {int quality = 90}) async {
    if (o.isEmpty) return pageJpg;
    final codec = await ui.instantiateImageCodec(pageJpg);
    final base = (await codec.getNextFrame()).image;
    final w = base.width.toDouble(), h = base.height.toDouble();

    final rec = ui.PictureRecorder();
    final c = ui.Canvas(rec);
    c.drawImage(base, Offset.zero, ui.Paint());

    final erase = ui.Paint()
      ..color = const Color(0xFFFFFFFF)
      ..style = ui.PaintingStyle.stroke
      ..strokeCap = ui.StrokeCap.round
      ..strokeJoin = ui.StrokeJoin.round;
    for (final s in o.strokes) {
      erase.strokeWidth = s.width * w;
      final pts = s.points.map((e) => Offset(e.dx * w, e.dy * h)).toList();
      if (pts.length == 1) {
        c.drawCircle(pts.first, s.width * w / 2,
            ui.Paint()..color = const Color(0xFFFFFFFF));
      } else {
        final path = ui.Path()..moveTo(pts.first.dx, pts.first.dy);
        for (final p in pts.skip(1)) {
          path.lineTo(p.dx, p.dy);
        }
        c.drawPath(path, erase);
      }
    }

    for (final pl in o.placements) {
      final img = (await (await ui.instantiateImageCodec(pl.png)).getNextFrame()).image;
      final dw = pl.w * w, dh = dw / pl.aspect;
      final dst = Rect.fromCenter(
          center: Offset(pl.cx * w, pl.cy * h), width: dw, height: dh);
      c.drawImageRect(
          img,
          Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
          dst,
          ui.Paint()..filterQuality = FilterQuality.high);
    }

    if (o.watermark.trim().isNotEmpty) {
      final tp = TextPainter(
        text: TextSpan(
          text: o.watermark.trim(),
          style: TextStyle(
            color: const Color(0x2E000000),
            fontSize: w * 0.07,
            fontWeight: FontWeight.w700,
          ),
        ),
        textDirection: _isArabic(o.watermark) ? TextDirection.rtl : TextDirection.ltr,
      )..layout();
      c.save();
      c.translate(w / 2, h / 2);
      c.rotate(-math.pi / 6);
      final stepX = tp.width * 1.4, stepY = tp.height * 3.2;
      final reach = math.sqrt(w * w + h * h);
      for (var y = -reach; y < reach; y += stepY) {
        for (var x = -reach; x < reach; x += stepX) {
          tp.paint(c, Offset(x, y));
        }
      }
      c.restore();
    }

    final out = await rec.endRecording().toImage(base.width, base.height);
    final data = await out.toByteData(format: ui.ImageByteFormat.rawRgba);
    final rgba = data!.buffer.asUint8List();
    return compute(_encode, {'w': base.width, 'h': base.height, 'rgba': rgba, 'q': quality});
  }

  static bool _isArabic(String s) => RegExp(r'[؀-ۿ]').hasMatch(s);
}

Uint8List _encode(Map<String, dynamic> m) =>
    RgbImage.fromRgba(m['w'] as int, m['h'] as int, m['rgba'] as Uint8List)
        .encodeJpg(quality: m['q'] as int);

