import '../imaging/filters.dart';

class PageModel {
  PageModel({
    required this.id,
    required this.origFile,
    required this.procFile,
    required this.origW,
    required this.origH,
    required this.quad,
    this.filter = ScanFilter.magic,
    this.shadow = true,
    this.fingers = false,
    this.flatten = false,
    this.rotation = 0,
    this.ocrText,
  });

  final String id;
  final String origFile; // file name inside the document directory
  String procFile;
  final int origW, origH;
  List<double>? quad; // 8 normalised numbers, null = no crop
  ScanFilter filter;
  bool shadow;
  bool fingers;
  bool flatten; // flatten curved lines (book pages)
  int rotation;
  String? ocrText;

  Map<String, dynamic> toJson() => {
        'id': id,
        'orig': origFile,
        'proc': procFile,
        'w': origW,
        'h': origH,
        'quad': quad,
        'filter': filter.index,
        'shadow': shadow,
        'fingers': fingers,
        'flatten': flatten,
        'rotation': rotation,
        'ocr': ocrText,
      };

  factory PageModel.fromJson(Map<String, dynamic> j) => PageModel(
        id: j['id'] as String,
        origFile: j['orig'] as String,
        procFile: j['proc'] as String,
        origW: j['w'] as int,
        origH: j['h'] as int,
        quad: (j['quad'] as List?)?.map((e) => (e as num).toDouble()).toList(),
        filter: ScanFilter.values[(j['filter'] as int?) ?? 1],
        shadow: (j['shadow'] as bool?) ?? true,
        fingers: (j['fingers'] as bool?) ?? false,
        flatten: (j['flatten'] as bool?) ?? false,
        rotation: (j['rotation'] as int?) ?? 0,
        ocrText: j['ocr'] as String?,
      );
}

class DocModel {
  DocModel({
    required this.id,
    required this.name,
    this.folderId,
    DateTime? created,
    List<PageModel>? pages,
  })  : created = created ?? DateTime.now(),
        pages = pages ?? [];

  final String id;
  String name;
  String? folderId;
  final DateTime created;
  final List<PageModel> pages;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'folder': folderId,
        'created': created.toIso8601String(),
        'pages': pages.map((p) => p.toJson()).toList(),
      };

  factory DocModel.fromJson(Map<String, dynamic> j) => DocModel(
        id: j['id'] as String,
        name: j['name'] as String,
        folderId: j['folder'] as String?,
        created: DateTime.tryParse(j['created'] as String? ?? ''),
        pages: (j['pages'] as List)
            .map((e) => PageModel.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

class FolderModel {
  FolderModel({required this.id, required this.name, this.parentId});
  final String id;
  String name;
  final String? parentId;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'parent': parentId};
  factory FolderModel.fromJson(Map<String, dynamic> j) => FolderModel(
        id: j['id'] as String,
        name: j['name'] as String,
        parentId: j['parent'] as String?,
      );
}
