import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'screens/home_screen.dart';
import 'services/export_service.dart';
import 'services/library_service.dart';
import 'services/page_factory.dart';
import 'services/settings_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final lib = LibraryService();
  final settings = SettingsService();
  await Future.wait([lib.init(), settings.init()]);
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: lib),
      ChangeNotifierProvider.value(value: settings),
      Provider(create: (_) => PageFactory(lib)),
      Provider(create: (_) => ExportService(lib)),
    ],
    child: const SimoApp(),
  ));
}

class SimoApp extends StatelessWidget {
  const SimoApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    return MaterialApp(
      title: 'SiMo Scan Pro',
      debugShowCheckedModeBanner: false,
      locale: settings.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      localeResolutionCallback: (l, supported) {
        if (l != null && l.languageCode == 'ar') return const Locale('ar');
        return const Locale('en');
      },
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      home: const HomeScreen(),
    );
  }
}
