import 'package:flutter/material.dart';

class AppColors {
  static const ink = Color(0xFF0B1B3A);
  static const blue = Color(0xFF2F5BEA);
  static const gold = Color(0xFFF2B01E);
}

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue,
    brightness: b,
    secondary: AppColors.gold,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    appBarTheme: const AppBarTheme(centerTitle: false),
    cardTheme: CardThemeData(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: scheme.surfaceContainerHighest.withValues(alpha: .5),
    ),
  );
}
