import 'dart:math' as math;
import 'dart:typed_data';

import 'dewarp.dart';
import 'rgb_image.dart';

/// Straightens slightly rotated pages: finds the angle whose row projection
/// of ink is sharpest (text lines become horizontal), then rotates.
/// Verified in a Python prototype on a real tilted scan (-2.15 deg -> 0.0).
class Deskew {
  static RgbImage apply(RgbImage src) {
    final a = estimate(src);
    if (a.abs() < 0.15) return src;
    return rotate(src, a);
  }

  /// Angle in degrees (same convention as [rotate]).
  static double estimate(RgbImage src) {
    final small = src.limitedTo(600);
    final w = small.width, h = small.height;
    final ink = Dewarp.inkMap(small.toGray(), w, h);

    // Collect ink pixels (subsampled to <= ~60k points).
    final xs = <double>[], ys = <double>[], ws = <double>[];
    final cx = w / 2, cy = h / 2;
    var count = 0;
    for (var i = 0; i < ink.length; i++) {
      if (ink[i] > 25) count++;
    }
    if (count < 300) return 0;
    final stride = math.max(1, count ~/ 60000);
    var k = 0;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final v = ink[y * w + x];
        if (v > 25 && (k++ % stride) == 0) {
          xs.add(x - cx);
          ys.add(y - cy);
          ws.add(v.toDouble());
        }
      }
    }
    final n = xs.length;
    final diag = math.sqrt((w * w + h * h).toDouble()).ceil() + 4;
    final hist = Float64List(diag * 2 + 1);

    double score(double deg) {
      hist.fillRange(0, hist.length, 0);
      final t = deg * math.pi / 180;
      final s = math.sin(t), c = math.cos(t);
      for (var i = 0; i < n; i++) {
        final r = (-xs[i] * s + ys[i] * c).round() + diag;
        hist[r] += ws[i];
      }
      var sum = 0.0;
      for (final v in hist) {
        sum += v * v;
      }
      return sum;
    }

    var best = 0.0, bestScore = -1.0;
    for (var a = -6.0; a <= 6.0001; a += 0.25) {
      final sc = score(a);
      if (sc > bestScore) {
        bestScore = sc;
        best = a;
      }
    }
    var fine = best, fineScore = bestScore;
    for (var a = best - 0.25; a <= best + 0.2501; a += 0.05) {
      final sc = score(a);
      if (sc > fineScore) {
        fineScore = sc;
        fine = a;
      }
    }
    return fineScore > score(0) * 1.02 ? fine : 0;
  }

  /// output(u, v) = src(u cos a - v sin a, u sin a + v cos a) about the
  /// centre; corners are filled with white.
  static RgbImage rotate(RgbImage src, double deg) {
    final w = src.width, h = src.height;
    final t = deg * math.pi / 180;
    final c = math.cos(t), s = math.sin(t);
    final out = Uint8List(src.data.length)..fillRange(0, src.data.length, 255);
    final d = src.data;
    final hw = w / 2, hh = h / 2;
    for (var y = 0; y < h; y++) {
      final v = y - hh;
      for (var x = 0; x < w; x++) {
        final u = x - hw;
        final sx = u * c - v * s + hw;
        final sy = u * s + v * c + hh;
        if (sx < 0 || sy < 0 || sx > w - 1 || sy > h - 1) continue;
        final x0 = sx.floor(), y0 = sy.floor();
        final x1 = math.min(w - 1, x0 + 1), y1 = math.min(h - 1, y0 + 1);
        final fx = sx - x0, fy = sy - y0;
        final i00 = (y0 * w + x0) * 3, i10 = (y0 * w + x1) * 3;
        final i01 = (y1 * w + x0) * 3, i11 = (y1 * w + x1) * 3;
        final o = (y * w + x) * 3;
        for (var k = 0; k < 3; k++) {
          final top = d[i00 + k] + (d[i10 + k] - d[i00 + k]) * fx;
          final bot = d[i01 + k] + (d[i11 + k] - d[i01 + k]) * fx;
          out[o + k] = (top + (bot - top) * fy).round();
        }
      }
    }
    return RgbImage(w, h, out);
  }
}
