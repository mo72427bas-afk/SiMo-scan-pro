import 'dart:math' as math;
import 'dart:typed_data';

import 'dewarp.dart';
import 'rgb_image.dart';

/// Straightens pages. Two things are corrected at once:
///  * a plain rotation (the whole page is tilted), and
///  * a slow drift of the tilt from the top of the page to the bottom
///    (keystone error from an imperfect crop), e.g. +0.6 deg at the top and
///    -1.0 deg at the bottom.
/// The tilt is measured per horizontal band (the angle whose row projection
/// of ink is sharpest), a straight line a(y) is fitted through the bands, and
/// the page is re-sampled with a vertical shear that follows that line.
/// Verified in a Python prototype on a real app output: every band went from
/// -1.0..+0.6 deg to 0.0 deg.
class Deskew {
  static RgbImage apply(RgbImage src) {
    final small = src.limitedTo(600);
    final p = _collect(small);
    if (p == null) return src;
    final w = small.width, h = small.height;
    final diag = math.sqrt((w * w + h * h).toDouble()).ceil() + 4;

    // --- per-band angles ---
    final bys = <double>[], bas = <double>[], bws = <double>[];
    final half = 0.16 * h;
    for (var i = 0; i < 7; i++) {
      final c = (-0.36 + i * 0.12) * h;
      final xs = <double>[], ys = <double>[], ws = <double>[];
      for (var k = 0; k < p.xs.length; k++) {
        if ((p.ys[k] - c).abs() <= half) {
          xs.add(p.xs[k]);
          ys.add(p.ys[k]);
          ws.add(p.ws[k]);
        }
      }
      if (xs.length < 200) continue;
      final r = _best(xs, ys, ws, diag, 4.0);
      if (r[1] > 1.03 || r[0].abs() < 0.05) {
        bys.add(c);
        bas.add(r[0]);
        bws.add(math.max(r[1] - 1, 0.02));
      }
    }

    double a0, a1;
    if (bys.length >= 3) {
      var fit = _fitLine(bys, bas, bws);
      // Drop outlier bands once and refit.
      final res = [
        for (var i = 0; i < bys.length; i++) bas[i] - (fit[0] + fit[1] * bys[i])
      ];
      var mean = 0.0;
      for (final r in res) {
        mean += r * r;
      }
      final std = math.sqrt(mean / res.length);
      final lim = math.max(0.4, 2 * std);
      final ky = <double>[], ka = <double>[], kw = <double>[];
      for (var i = 0; i < bys.length; i++) {
        if (res[i].abs() <= lim) {
          ky.add(bys[i]);
          ka.add(bas[i]);
          kw.add(bws[i]);
        }
      }
      if (ky.length >= 3) fit = _fitLine(ky, ka, kw);
      a0 = fit[0];
      a1 = fit[1];
    } else {
      // Not enough structure for bands: single global angle.
      final r = _best(p.xs, p.ys, p.ws, diag, 6.0);
      a0 = r[1] > 1.02 ? r[0] : 0.0;
      a1 = 0.0;
    }

    // Safety limits.
    a0 = a0.clamp(-6.0, 6.0).toDouble();
    final drift = (a1 * h).abs(); // total change top -> bottom (degrees)
    if (drift > 4.0) a1 = a1 * 4.0 / drift;
    final top = a0 + a1 * (-h / 2), bottom = a0 + a1 * (h / 2);
    if (top.abs() < 0.12 && bottom.abs() < 0.12) return src;

    // a1 was measured in pixels of the small copy; convert to full size.
    final a1Full = a1 * (small.height / src.height);
    return _shear(src, a0, a1Full);
  }

  /// Angle in degrees of the whole page (same convention as [rotate]).
  static double estimate(RgbImage src) {
    final small = src.limitedTo(600);
    final p = _collect(small);
    if (p == null) return 0;
    final w = small.width, h = small.height;
    final diag = math.sqrt((w * w + h * h).toDouble()).ceil() + 4;
    final r = _best(p.xs, p.ys, p.ws, diag, 6.0);
    return r[1] > 1.02 ? r[0] : 0;
  }

  // ---------------------------------------------------------------------

  static _Pts? _collect(RgbImage small) {
    final w = small.width, h = small.height;
    final ink = Dewarp.inkMap(small.toGray(), w, h);
    var count = 0;
    for (var i = 0; i < ink.length; i++) {
      if (ink[i] > 25) count++;
    }
    if (count < 300) return null;
    final stride = math.max(1, count ~/ 60000);
    final xs = <double>[], ys = <double>[], ws = <double>[];
    final cx = w / 2, cy = h / 2;
    var k = 0;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final v = ink[y * w + x];
        if (v > 25 && (k++ % stride) == 0) {
          xs.add(x - cx);
          ys.add(y - cy);
          ws.add(v.toDouble());
        }
      }
    }
    return _Pts(xs, ys, ws);
  }

  /// Best angle in [-range, range] and how much sharper it is than 0 deg.
  static List<double> _best(List<double> xs, List<double> ys, List<double> ws,
      int diag, double range) {
    final n = xs.length;
    final hist = Float64List(diag * 2 + 1);

    double score(double deg) {
      hist.fillRange(0, hist.length, 0);
      final t = deg * math.pi / 180;
      final s = math.sin(t), c = math.cos(t);
      for (var i = 0; i < n; i++) {
        final r = (-xs[i] * s + ys[i] * c).round() + diag;
        if (r >= 0 && r < hist.length) hist[r] += ws[i];
      }
      var sum = 0.0;
      for (final v in hist) {
        sum += v * v;
      }
      return sum;
    }

    var best = 0.0, bestScore = -1.0;
    for (var a = -range; a <= range + 0.0001; a += 0.25) {
      final sc = score(a);
      if (sc > bestScore) {
        bestScore = sc;
        best = a;
      }
    }
    var fine = best, fineScore = bestScore;
    for (var a = best - 0.25; a <= best + 0.2501; a += 0.05) {
      final sc = score(a);
      if (sc > fineScore) {
        fineScore = sc;
        fine = a;
      }
    }
    final s0 = score(0);
    return [fine, s0 > 0 ? fineScore / s0 : 1.0];
  }

  /// Weighted least-squares line a = a0 + a1 * y. Returns [a0, a1].
  static List<double> _fitLine(
      List<double> ys, List<double> angs, List<double> ws) {
    var sw = 0.0, sy = 0.0, sa = 0.0, syy = 0.0, sya = 0.0;
    for (var i = 0; i < ys.length; i++) {
      final w = ws[i];
      sw += w;
      sy += w * ys[i];
      sa += w * angs[i];
      syy += w * ys[i] * ys[i];
      sya += w * ys[i] * angs[i];
    }
    final den = sw * syy - sy * sy;
    if (den.abs() < 1e-9) return [sw > 0 ? sa / sw : 0.0, 0.0];
    final a1 = (sw * sya - sy * sa) / den;
    final a0 = (sa - a1 * sy) / sw;
    return [a0, a1];
  }

  /// out(x, y) = src(x, y + tan(a(y)) * (x - cx)) with a(y) = a0 + a1 * (y - cy)
  /// (degrees). Vertical-only bilinear sampling; uncovered pixels are white.
  static RgbImage _shear(RgbImage src, double a0, double a1) {
    final w = src.width, h = src.height;
    final d = src.data;
    final out = Uint8List(d.length)..fillRange(0, d.length, 255);
    final hw = w / 2, hh = h / 2;
    for (var y = 0; y < h; y++) {
      final aDeg = a0 + a1 * (y - hh);
      final t = math.tan(aDeg * math.pi / 180);
      for (var x = 0; x < w; x++) {
        final sy = y + t * (x - hw);
        if (sy < 0 || sy > h - 1) continue;
        final y0 = sy.floor();
        final y1 = math.min(h - 1, y0 + 1);
        final fy = sy - y0;
        final i0 = (y0 * w + x) * 3, i1 = (y1 * w + x) * 3;
        final o = (y * w + x) * 3;
        for (var k = 0; k < 3; k++) {
          out[o + k] = (d[i0 + k] + (d[i1 + k] - d[i0 + k]) * fy).round();
        }
      }
    }
    return RgbImage(w, h, out);
  }

  /// output(u, v) = src(u cos a - v sin a, u sin a + v cos a) about the
  /// centre; corners are filled with white.
  static RgbImage rotate(RgbImage src, double deg) {
    final w = src.width, h = src.height;
    final t = deg * math.pi / 180;
    final c = math.cos(t), s = math.sin(t);
    final out = Uint8List(src.data.length)..fillRange(0, src.data.length, 255);
    final d = src.data;
    final hw = w / 2, hh = h / 2;
    for (var y = 0; y < h; y++) {
      final v = y - hh;
      for (var x = 0; x < w; x++) {
        final u = x - hw;
        final sx = u * c - v * s + hw;
        final sy = u * s + v * c + hh;
        if (sx < 0 || sy < 0 || sx > w - 1 || sy > h - 1) continue;
        final x0 = sx.floor(), y0 = sy.floor();
        final x1 = math.min(w - 1, x0 + 1), y1 = math.min(h - 1, y0 + 1);
        final fx = sx - x0, fy = sy - y0;
        final i00 = (y0 * w + x0) * 3, i10 = (y0 * w + x1) * 3;
        final i01 = (y1 * w + x0) * 3, i11 = (y1 * w + x1) * 3;
        final o = (y * w + x) * 3;
        for (var k = 0; k < 3; k++) {
          final top = d[i00 + k] + (d[i10 + k] - d[i00 + k]) * fx;
          final bot = d[i01 + k] + (d[i11 + k] - d[i01 + k]) * fx;
          out[o + k] = (top + (bot - top) * fy).round();
        }
      }
    }
    return RgbImage(w, h, out);
  }
}

class _Pts {
  _Pts(this.xs, this.ys, this.ws);
  final List<double> xs, ys, ws;
}
