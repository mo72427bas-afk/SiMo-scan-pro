import 'dart:math' as math;
import 'dart:typed_data';

import 'rgb_image.dart';

// New values are appended: filters are stored by index in saved documents.
enum ScanFilter { original, magic, gray, bw, pro, lighten }

/// Image filters: illumination normalisation (shadow/stain removal),
/// Magic Color, grayscale, black & white (adaptive threshold) and a
/// heuristic finger remover.
class Filters {
  static RgbImage apply(RgbImage src, ScanFilter f, {required bool shadow}) {
    final base = shadow ? normalizeIllumination(src) : src;
    switch (f) {
      case ScanFilter.original:
        return base;
      case ScanFilter.magic:
        return magicColor(base);
      case ScanFilter.gray:
        return grayscale(base);
      case ScanFilter.bw:
        return blackWhite(base);
      case ScanFilter.pro:
        return magicPro(base);
      case ScanFilter.lighten:
        return lighten(base);
    }
  }

  // ---------------------------------------------------------------------
  // Shadow & stain removal: estimate the paper (background) brightness per
  // channel on a small copy (max filter + blur), then divide it out.
  // ---------------------------------------------------------------------
  static RgbImage normalizeIllumination(RgbImage src) {
    final w = src.width, h = src.height;
    final f = math.max(1, math.max(w, h) ~/ 200);
    final sw = (w + f - 1) ~/ f, sh = (h + f - 1) ~/ f;
    final small = List.generate(3, (_) => Uint8List(sw * sh));
    final d = src.data;

    for (var y = 0; y < sh; y++) {
      for (var x = 0; x < sw; x++) {
        var r = 0, g = 0, b = 0, n = 0;
        final y0 = y * f, y1 = math.min(h, y0 + f);
        final x0 = x * f, x1 = math.min(w, x0 + f);
        for (var yy = y0; yy < y1; yy++) {
          var i = (yy * w + x0) * 3;
          for (var xx = x0; xx < x1; xx++) {
            r += d[i];
            g += d[i + 1];
            b += d[i + 2];
            i += 3;
            n++;
          }
        }
        final idx = y * sw + x;
        small[0][idx] = r ~/ n;
        small[1][idx] = g ~/ n;
        small[2][idx] = b ~/ n;
      }
    }
    final bg = [
      for (var c = 0; c < 3; c++)
        _boxBlur(_dilate(small[c], sw, sh, 2), sw, sh, 3),
    ];

    // Bilinear lookup tables along x.
    final x0s = Int32List(w), x1s = Int32List(w);
    final fxs = Float64List(w);
    for (var x = 0; x < w; x++) {
      var fx = (x + 0.5) / f - 0.5;
      if (fx < 0) fx = 0;
      if (fx > sw - 1) fx = (sw - 1).toDouble();
      final i0 = fx.floor();
      x0s[x] = i0;
      x1s[x] = math.min(i0 + 1, sw - 1);
      fxs[x] = fx - i0;
    }

    final out = Uint8List(d.length);
    var o = 0;
    for (var y = 0; y < h; y++) {
      var fy = (y + 0.5) / f - 0.5;
      if (fy < 0) fy = 0;
      if (fy > sh - 1) fy = (sh - 1).toDouble();
      final y0 = fy.floor();
      final y1 = math.min(y0 + 1, sh - 1);
      final ty = fy - y0;
      for (var x = 0; x < w; x++) {
        final tx = fxs[x];
        final a = y0 * sw + x0s[x], b = y0 * sw + x1s[x];
        final c = y1 * sw + x0s[x], e = y1 * sw + x1s[x];
        for (var ch = 0; ch < 3; ch++) {
          final p = bg[ch];
          final top = p[a] + (p[b] - p[a]) * tx;
          final bot = p[c] + (p[e] - p[c]) * tx;
          final bgv = math.max(60.0, top + (bot - top) * ty);
          final v = d[o] * 255.0 / bgv;
          out[o] = v > 255 ? 255 : v.toInt();
          o++;
        }
      }
    }
    return RgbImage(w, h, out);
  }

  // ---------------------------------------------------------------------
  // Magic Color HD: punchy contrast curve + saturation boost.
  // Expects an illumination-normalised image for a pure white background.
  // ---------------------------------------------------------------------
  static RgbImage magicColor(RgbImage src) {
    // Strong "scanner" look: dark crisp text, pure white paper, colours kept.
    final lut = _textLut(0.30, 0.90, 1.25);
    final d = src.data;
    final out = Uint8List(d.length);
    for (var i = 0; i < d.length; i += 3) {
      final r = lut[d[i]], g = lut[d[i + 1]], b = lut[d[i + 2]];
      final l = (r * 77 + g * 150 + b * 29) >> 8;
      out[i] = _c(l + (r - l) * 1.15);
      out[i + 1] = _c(l + (g - l) * 1.15);
      out[i + 2] = _c(l + (b - l) * 1.15);
    }
    return _sharpen(RgbImage(src.width, src.height, out), 0.9);
  }

  static Uint8List _textLut(double black, double white, double gamma) {
    final lut = Uint8List(256);
    for (var i = 0; i < 256; i++) {
      final x = ((i / 255 - black) / (white - black)).clamp(0.0, 1.0);
      lut[i] = (math.pow(x, gamma) * 255).round();
    }
    return lut;
  }

  /// Applies a filter to an image that was already illumination-normalised
  /// (and deskewed / border-cleaned).
  static RgbImage applyNormalized(RgbImage base, ScanFilter f) {
    switch (f) {
      case ScanFilter.original:
        return base;
      case ScanFilter.magic:
        return magicColor(base);
      case ScanFilter.gray:
        return grayscale(base);
      case ScanFilter.bw:
        return blackWhite(base);
      case ScanFilter.pro:
        return magicPro(base);
      case ScanFilter.lighten:
        return lighten(base);
    }
  }

  /// Magic Pro: steep curve, bolder strokes, colours kept, faint stamps and
  /// blotches removed (thin lines and real ink are kept), paper tint -> white.
  /// Tuned against CamScanner results on real photos.
  static RgbImage magicPro(RgbImage src) {
    final w = src.width, h = src.height, n = w * h;
    final lut = _textLut(0.50, 0.80, 1.0);
    final d = src.data;
    final out = Uint8List(d.length);
    final g = Uint8List(n);
    for (var p = 0, i = 0; p < n; p++, i += 3) {
      final r = lut[d[i]], gg = lut[d[i + 1]], b = lut[d[i + 2]];
      final l = (r * 77 + gg * 150 + b * 29) >> 8;
      out[i] = _c(l + (r - l) * 1.1);
      out[i + 1] = _c(l + (gg - l) * 1.1);
      out[i + 2] = _c(l + (b - l) * 1.1);
      g[p] = l;
    }

    // Faint broad blobs (stamps, stains) far from real ink -> white.
    final s = math.max(1, (w / 900).round());
    final ink = Uint8List(n), faint = Uint8List(n);
    for (var p = 0; p < n; p++) {
      ink[p] = g[p] < 150 ? 1 : 0;
      faint[p] = (g[p] >= 150 && g[p] < 240) ? 1 : 0;
    }
    final near = _dilate(ink, w, h, s);
    for (var p = 0; p < n; p++) {
      if (near[p] == 1) faint[p] = 0;
    }
    final blob = _dilate(_dilate(_erode(faint, w, h, s), w, h, s), w, h, s);
    for (var p = 0; p < n; p++) {
      if (blob[p] == 1 && faint[p] == 1) {
        out[p * 3] = 255;
        out[p * 3 + 1] = 255;
        out[p * 3 + 2] = 255;
      }
    }

    final bold = _sharpen(_thicken(RgbImage(w, h, out), 0.6), 1.0);

    // Weakly coloured bright pixels (paper tint) -> pure white.
    final o = bold.data;
    for (var i = 0; i < o.length; i += 3) {
      final r = o[i], gg = o[i + 1], b = o[i + 2];
      final mx = math.max(r, math.max(gg, b));
      final mn = math.min(r, math.min(gg, b));
      final l = (r * 77 + gg * 150 + b * 29) >> 8;
      final bright = ((l - 190) / 45).clamp(0.0, 1.0);
      final weak = ((70 - (mx - mn)) / 40).clamp(0.0, 1.0);
      final k = bright * weak;
      if (k > 0) {
        o[i] = _c(r + (255 - r) * k);
        o[i + 1] = _c(gg + (255 - gg) * k);
        o[i + 2] = _c(b + (255 - b) * k);
      }
    }
    return bold;
  }

  static Uint8List _erode(Uint8List m, int w, int h, int r) {
    final inv = Uint8List(m.length);
    for (var i = 0; i < m.length; i++) {
      inv[i] = m[i] == 0 ? 1 : 0;
    }
    final d = _dilate(inv, w, h, r);
    for (var i = 0; i < d.length; i++) {
      d[i] = d[i] == 0 ? 1 : 0;
    }
    return d;
  }

  /// Lighten: keeps the look of the paper, just brighter and cleaner.
  static RgbImage lighten(RgbImage src) {
    final lut = _textLut(0.05, 0.88, 0.9);
    final d = src.data;
    final out = Uint8List(d.length);
    for (var i = 0; i < d.length; i++) {
      out[i] = lut[d[i]];
    }
    return _sharpen(RgbImage(src.width, src.height, out), 0.5);
  }

  /// Blends each pixel with the darkest of its 2x2 neighbourhood.
  static RgbImage _thicken(RgbImage src, double amt) {
    final w = src.width, h = src.height, d = src.data;
    final out = Uint8List(d.length);
    for (var y = 0; y < h; y++) {
      final y1 = y + 1 < h ? y + 1 : y;
      for (var x = 0; x < w; x++) {
        final x1 = x + 1 < w ? x + 1 : x;
        final i0 = (y * w + x) * 3, i1 = (y * w + x1) * 3;
        final i2 = (y1 * w + x) * 3, i3 = (y1 * w + x1) * 3;
        for (var c = 0; c < 3; c++) {
          var m = d[i0 + c];
          if (d[i1 + c] < m) m = d[i1 + c];
          if (d[i2 + c] < m) m = d[i2 + c];
          if (d[i3 + c] < m) m = d[i3 + c];
          out[i0 + c] = _c(d[i0 + c] * (1 - amt) + m * amt);
        }
      }
    }
    return RgbImage(w, h, out);
  }

  /// Whitens dark scanner/table edge lines in a thin band along the border.
  static RgbImage cleanBorders(RgbImage src) {
    final w = src.width, h = src.height;
    final band = math.max(2, (math.min(w, h) * 0.012).round());
    final d = Uint8List.fromList(src.data);
    void fix(int x, int y) {
      final i = (y * w + x) * 3;
      final l = (d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8;
      if (l < 150) {
        d[i] = 255;
        d[i + 1] = 255;
        d[i + 2] = 255;
      }
    }

    for (var y = 0; y < h; y++) {
      final inY = y < band || y >= h - band;
      for (var x = 0; x < w; x++) {
        if (inY || x < band || x >= w - band) fix(x, y);
      }
    }
    return RgbImage(w, h, d);
  }

  static RgbImage grayscale(RgbImage src) {
    final lut = _textLut(0.25, 0.90, 1.2);
    final d = src.data;
    final out = Uint8List(d.length);
    for (var i = 0; i < d.length; i += 3) {
      final l = lut[(d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8];
      out[i] = l;
      out[i + 1] = l;
      out[i + 2] = l;
    }
    return _sharpen(RgbImage(src.width, src.height, out), 0.6);
  }

  /// Pure black & white using a local mean (integral image) threshold.
  static RgbImage blackWhite(RgbImage src) {
    final w = src.width, h = src.height;
    final gray = src.toGray();
    final iw = w + 1;
    final integral = Int32List(iw * (h + 1));
    for (var y = 0; y < h; y++) {
      var row = 0;
      for (var x = 0; x < w; x++) {
        row += gray[y * w + x];
        integral[(y + 1) * iw + x + 1] = integral[y * iw + x + 1] + row;
      }
    }
    final r = math.max(8, math.min(w, h) ~/ 30);
    final out = Uint8List(w * h * 3);
    for (var y = 0; y < h; y++) {
      final y0 = math.max(0, y - r), y1 = math.min(h, y + r + 1);
      for (var x = 0; x < w; x++) {
        final x0 = math.max(0, x - r), x1 = math.min(w, x + r + 1);
        final sum = integral[y1 * iw + x1] -
            integral[y0 * iw + x1] -
            integral[y1 * iw + x0] +
            integral[y0 * iw + x0];
        final mean = sum / ((x1 - x0) * (y1 - y0));
        final v = gray[y * w + x];
        final white = !(v < mean * 0.90 || v < 70) || v > 235;
        final o = (y * w + x) * 3;
        final c = white ? 255 : 0;
        out[o] = c;
        out[o + 1] = c;
        out[o + 2] = c;
      }
    }
    return RgbImage(w, h, out);
  }

  // ---------------------------------------------------------------------
  // Finger removal (heuristic): skin-coloured pixels that touch the page
  // border band are painted with the paper colour.
  // ---------------------------------------------------------------------
  static RgbImage removeFingers(RgbImage src) {
    final w = src.width, h = src.height;
    final d = src.data;
    final bandX = (w * 0.16).round(), bandY = (h * 0.16).round();

    bool isSkin(int r, int g, int b) {
      final y = 0.299 * r + 0.587 * g + 0.114 * b;
      final cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      final cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      return y > 40 && cb >= 77 && cb <= 127 && cr >= 135 && cr <= 175;
    }

    // Paper colour: mean of bright, non-skin pixels (sampled).
    var pr = 0, pg = 0, pb = 0, pn = 0;
    for (var y = 0; y < h; y += 4) {
      for (var x = 0; x < w; x += 4) {
        final i = (y * w + x) * 3;
        final l = (d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8;
        if (l > 190 && !isSkin(d[i], d[i + 1], d[i + 2])) {
          pr += d[i];
          pg += d[i + 1];
          pb += d[i + 2];
          pn++;
        }
      }
    }
    final fr = pn > 0 ? pr ~/ pn : 255;
    final fg = pn > 0 ? pg ~/ pn : 255;
    final fb = pn > 0 ? pb ~/ pn : 255;

    var mask = Uint8List(w * h);
    for (var y = 0; y < h; y++) {
      final inBandY = y < bandY || y >= h - bandY;
      for (var x = 0; x < w; x++) {
        if (!(inBandY || x < bandX || x >= w - bandX)) continue;
        final i = (y * w + x) * 3;
        if (isSkin(d[i], d[i + 1], d[i + 2])) mask[y * w + x] = 1;
      }
    }
    mask = _dilate(mask, w, h, 3);

    final out = Uint8List.fromList(d);
    for (var p = 0; p < mask.length; p++) {
      if (mask[p] == 1) {
        out[p * 3] = fr;
        out[p * 3 + 1] = fg;
        out[p * 3 + 2] = fb;
      }
    }
    return RgbImage(w, h, out);
  }

  // ---------------------------------------------------------------------
  /// Mild unsharp mask (3x3 box blur) to crisp up soft camera text.
  static RgbImage _sharpen(RgbImage src, double amount) {
    final w = src.width, h = src.height;
    final d = src.data;
    final tmp = Uint8List(d.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final xl = (x > 0 ? x - 1 : x), xr = (x < w - 1 ? x + 1 : x);
        final a = (y * w + xl) * 3, b = (y * w + x) * 3, c = (y * w + xr) * 3;
        for (var k = 0; k < 3; k++) {
          tmp[b + k] = (d[a + k] + d[b + k] + d[c + k]) ~/ 3;
        }
      }
    }
    final out = Uint8List(d.length);
    for (var y = 0; y < h; y++) {
      final yu = (y > 0 ? y - 1 : y), yd = (y < h - 1 ? y + 1 : y);
      for (var x = 0; x < w; x++) {
        final a = (yu * w + x) * 3, b = (y * w + x) * 3, c = (yd * w + x) * 3;
        for (var k = 0; k < 3; k++) {
          final blur = (tmp[a + k] + tmp[b + k] + tmp[c + k]) / 3;
          out[b + k] = _c(d[b + k] + amount * (d[b + k] - blur));
        }
      }
    }
    return RgbImage(w, h, out);
  }

  static int _c(num v) => v < 0 ? 0 : (v > 255 ? 255 : v.round());

  static Uint8List _dilate(Uint8List m, int w, int h, int r) {
    final tmp = Uint8List(m.length);
    final out = Uint8List(m.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = 0;
        for (var k = math.max(0, x - r); k <= math.min(w - 1, x + r); k++) {
          if (m[y * w + k] > v) v = m[y * w + k];
        }
        tmp[y * w + x] = v;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = 0;
        for (var k = math.max(0, y - r); k <= math.min(h - 1, y + r); k++) {
          if (tmp[k * w + x] > v) v = tmp[k * w + x];
        }
        out[y * w + x] = v;
      }
    }
    return out;
  }

  static Uint8List _boxBlur(Uint8List m, int w, int h, int r) {
    final tmp = Uint8List(m.length);
    final out = Uint8List(m.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var s = 0, n = 0;
        for (var k = math.max(0, x - r); k <= math.min(w - 1, x + r); k++) {
          s += m[y * w + k];
          n++;
        }
        tmp[y * w + x] = s ~/ n;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var s = 0, n = 0;
        for (var k = math.max(0, y - r); k <= math.min(h - 1, y + r); k++) {
          s += tmp[k * w + x];
          n++;
        }
        out[y * w + x] = s ~/ n;
      }
    }
    return out;
  }
}
