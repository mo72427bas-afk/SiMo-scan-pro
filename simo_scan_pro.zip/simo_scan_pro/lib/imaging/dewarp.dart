import 'dart:math' as math;
import 'dart:typed_data';

import 'rgb_image.dart';

/// Flattens curved text lines (typical near a book spine) by estimating a
/// vertical shift per column strip from row-ink profiles, then re-sampling.
///
/// It is applied only when the global row profile becomes measurably
/// sharper (straight lines => sharper profile), otherwise the input is
/// returned unchanged. Horizontal squeeze near the spine is NOT corrected.
class Dewarp {
  static const _strips = 48;

  static RgbImage flatten(RgbImage src) {
    // Work on a small gray copy.
    final small = src.limitedTo(700);
    final w = small.width, h = small.height;
    if (w < _strips * 4 || h < 100) return src;
    final gray = small.toGray();

    final sw = w ~/ _strips;
    final maxs = math.max(2, (h * 0.04).round());

    // Local ink map: max(0, local mean - pixel), via integral image.
    final ink = inkMap(gray, w, h);

    final profs = <Float64List>[
      for (var s = 0; s < _strips; s++) _profile(ink, w, h, s * sw, (s + 1) * sw),
    ];
    final energy = [
      for (final p in profs) p.fold<double>(0, (a, b) => a + b.abs()),
    ];
    final sorted = List<double>.from(energy)..sort();
    final median = sorted[_strips ~/ 2];
    final ok = [for (final e in energy) e > 0.25 * median && e > 0];
    var ref = 0;
    for (var i = 1; i < _strips; i++) {
      if (energy[i] > energy[ref]) ref = i;
    }
    if (!ok[ref]) return src;

    final shifts = List<double>.filled(_strips, 0);
    for (final dir in const [1, -1]) {
      var cur = 0.0;
      var prev = ref;
      var i = ref + dir;
      while (i >= 0 && i < _strips) {
        if (ok[i] && ok[prev]) {
          cur += _bestShift(profs[prev], profs[i], h, maxs);
        }
        shifts[i] = cur;
        if (ok[i]) prev = i;
        i += dir;
      }
    }

    final xs = [for (var i = 0; i < _strips; i++) (i + 0.5) * sw];
    final valid = [for (var i = 0; i < _strips; i++) if (ok[i]) i];
    if (valid.length < 6) return src;
    // Fill strips without text: linear extrapolation at the ends,
    // interpolation inside.
    void extrapolate(List<int> pts, Iterable<int> targets) {
      if (pts.length < 3) return;
      final n = pts.length;
      var sx = 0.0, sy = 0.0, sxx = 0.0, sxy = 0.0;
      for (final i in pts) {
        sx += xs[i];
        sy += shifts[i];
        sxx += xs[i] * xs[i];
        sxy += xs[i] * shifts[i];
      }
      final den = n * sxx - sx * sx;
      if (den.abs() < 1e-9) return;
      final a = (n * sxy - sx * sy) / den;
      final b = (sy - a * sx) / n;
      for (final i in targets) {
        shifts[i] = a * xs[i] + b;
      }
    }

    final lo = valid.first, hi = valid.last;
    extrapolate(valid.sublist(0, math.min(6, valid.length)), [for (var i = 0; i < lo; i++) i]);
    extrapolate(valid.sublist(math.max(0, valid.length - 6)),
        [for (var i = hi + 1; i < _strips; i++) i]);
    for (var i = lo; i <= hi; i++) {
      if (ok[i]) continue;
      var l = i - 1, r = i + 1;
      while (!ok[l]) {
        l--;
      }
      while (!ok[r]) {
        r++;
      }
      final t = (xs[i] - xs[l]) / (xs[r] - xs[l]);
      shifts[i] = shifts[l] + (shifts[r] - shifts[l]) * t;
    }
    final smooth = _gauss(shifts, 1.2);

    // Per-column shift (small scale).
    final colShift = Float64List(w);
    for (var x = 0; x < w; x++) {
      colShift[x] = _interp(xs, smooth, x.toDouble());
    }

    // Safety check: is the straightened small image sharper?
    final before = _sharp(_profile(ink, w, h, 0, w));
    final shiftedInk = _shiftColumns(ink, w, h, colShift);
    final after = _sharp(_profile(shiftedInk, w, h, 0, w));
    if (after <= before * 1.02) return src;

    // Apply to the full-size image.
    final scale = src.height / h;
    final full = Float64List(src.width);
    for (var x = 0; x < src.width; x++) {
      // Linear lookup in the per-column table of the small image.
      final fx = (x * w / src.width).clamp(0, w - 1).toDouble();
      final x0 = fx.floor(), x1 = math.min(w - 1, x0 + 1);
      full[x] = (colShift[x0] + (colShift[x1] - colShift[x0]) * (fx - x0)) * scale;
    }
    return _remapRows(src, full);
  }

  // ---- helpers ------------------------------------------------------
  /// Local ink map: max(0, local mean - pixel).
  static Uint8List inkMap(Uint8List g, int w, int h) {
    final iw = w + 1;
    final integral = Int32List(iw * (h + 1));
    for (var y = 0; y < h; y++) {
      var row = 0;
      for (var x = 0; x < w; x++) {
        row += g[y * w + x];
        integral[(y + 1) * iw + x + 1] = integral[y * iw + x + 1] + row;
      }
    }
    const r = 15;
    final out = Uint8List(w * h);
    for (var y = 0; y < h; y++) {
      final y0 = math.max(0, y - r), y1 = math.min(h, y + r + 1);
      for (var x = 0; x < w; x++) {
        final x0 = math.max(0, x - r), x1 = math.min(w, x + r + 1);
        final sum = integral[y1 * iw + x1] -
            integral[y0 * iw + x1] -
            integral[y1 * iw + x0] +
            integral[y0 * iw + x0];
        final mean = sum / ((x1 - x0) * (y1 - y0));
        final d = mean - g[y * w + x];
        out[y * w + x] = d > 0 ? math.min(255, d.round()) : 0;
      }
    }
    return out;
  }

  static Float64List _profile(Uint8List ink, int w, int h, int x0, int x1) {
    final p = Float64List(h);
    for (var y = 0; y < h; y++) {
      var s = 0;
      for (var x = x0; x < x1; x++) {
        s += ink[y * w + x];
      }
      p[y] = s.toDouble();
    }
    final sm = _gauss(p, 1.5);
    var mean = 0.0;
    for (final v in sm) {
      mean += v;
    }
    mean /= h;
    return Float64List.fromList([for (final v in sm) v - mean]);
  }

  static List<double> _gauss(List<double> a, double sigma) {
    final r = (sigma * 3).ceil();
    final k = [for (var i = -r; i <= r; i++) math.exp(-(i * i) / (2 * sigma * sigma))];
    final ks = k.fold<double>(0, (x, y) => x + y);
    final n = a.length;
    final out = List<double>.filled(n, 0);
    for (var i = 0; i < n; i++) {
      var s = 0.0;
      for (var j = -r; j <= r; j++) {
        final idx = (i + j).clamp(0, n - 1);
        s += a[idx] * k[j + r];
      }
      out[i] = s / ks;
    }
    return out;
  }

  /// Shift s so that b(y + s) best matches a(y).
  static int _bestShift(Float64List a, Float64List b, int h, int maxs) {
    var bestV = -double.maxFinite, best = 0;
    for (var s = -maxs; s <= maxs; s++) {
      var v = 0.0;
      if (s >= 0) {
        for (var y = 0; y < h - s; y++) {
          v += a[y] * b[y + s];
        }
      } else {
        for (var y = -s; y < h; y++) {
          v += a[y] * b[y + s];
        }
      }
      if (v > bestV) {
        bestV = v;
        best = s;
      }
    }
    return best;
  }

  static double _interp(List<double> xs, List<double> ys, double x) {
    if (x <= xs.first) return ys.first;
    if (x >= xs.last) return ys.last;
    var i = 0;
    while (i < xs.length - 2 && xs[i + 1] < x) {
      i++;
    }
    final t = (x - xs[i]) / (xs[i + 1] - xs[i]);
    return ys[i] + (ys[i + 1] - ys[i]) * t;
  }

  static double _sharp(Float64List p) {
    var s = 0.0;
    for (final v in p) {
      s += v * v;
    }
    return s;
  }

  static Uint8List _shiftColumns(Uint8List m, int w, int h, Float64List shift) {
    final out = Uint8List(m.length);
    for (var x = 0; x < w; x++) {
      for (var y = 0; y < h; y++) {
        final sy = (y + shift[x]).clamp(0, h - 1).toDouble();
        final y0 = sy.floor(), y1 = math.min(h - 1, y0 + 1);
        final t = sy - y0;
        out[y * w + x] =
            (m[y0 * w + x] + (m[y1 * w + x] - m[y0 * w + x]) * t).round();
      }
    }
    return out;
  }

  static RgbImage _remapRows(RgbImage src, Float64List shift) {
    final w = src.width, h = src.height;
    final out = Uint8List(src.data.length);
    for (var x = 0; x < w; x++) {
      for (var y = 0; y < h; y++) {
        final sy = (y + shift[x]).clamp(0, h - 1).toDouble();
        final y0 = sy.floor(), y1 = math.min(h - 1, y0 + 1);
        final t = sy - y0;
        final i0 = (y0 * w + x) * 3, i1 = (y1 * w + x) * 3, o = (y * w + x) * 3;
        for (var c = 0; c < 3; c++) {
          out[o + c] =
              (src.data[i0 + c] + (src.data[i1 + c] - src.data[i0 + c]) * t).round();
        }
      }
    }
    return RgbImage(w, h, out);
  }
}
