import 'dart:math' as math;
import 'dart:typed_data';

import 'rgb_image.dart';

/// Point. Throughout the app quads use coordinates normalised to 0..1.
class Pt {
  const Pt(this.x, this.y);
  final double x;
  final double y;

  Pt operator +(Pt o) => Pt(x + o.x, y + o.y);
  Pt operator -(Pt o) => Pt(x - o.x, y - o.y);
  Pt scale(double sx, double sy) => Pt(x * sx, y * sy);
  double dist(Pt o) {
    final dx = x - o.x, dy = y - o.y;
    return math.sqrt(dx * dx + dy * dy);
  }

  Pt lerp(Pt o, double t) => Pt(x + (o.x - x) * t, y + (o.y - y) * t);
}

/// Four corners in order: top-left, top-right, bottom-right, bottom-left.
class Quad {
  const Quad(this.tl, this.tr, this.br, this.bl);

  final Pt tl, tr, br, bl;

  factory Quad.full({double inset = 0}) => Quad(
        Pt(inset, inset),
        Pt(1 - inset, inset),
        Pt(1 - inset, 1 - inset),
        Pt(inset, 1 - inset),
      );

  factory Quad.fromList(List<double> v) =>
      Quad(Pt(v[0], v[1]), Pt(v[2], v[3]), Pt(v[4], v[5]), Pt(v[6], v[7]));

  /// Orders four arbitrary points into tl, tr, br, bl.
  factory Quad.fromUnordered(List<Pt> p) {
    assert(p.length == 4);
    Pt pick(double Function(Pt) score, {required bool max}) {
      var best = p[0];
      for (final q in p) {
        if (max ? score(q) > score(best) : score(q) < score(best)) best = q;
      }
      return best;
    }

    return Quad(
      pick((q) => q.x + q.y, max: false),
      pick((q) => q.x - q.y, max: true),
      pick((q) => q.x + q.y, max: true),
      pick((q) => q.x - q.y, max: false),
    );
  }

  List<Pt> get points => [tl, tr, br, bl];

  List<double> toList() => [tl.x, tl.y, tr.x, tr.y, br.x, br.y, bl.x, bl.y];

  Quad withPoint(int i, Pt p) {
    final l = points..[i] = p;
    return Quad(l[0], l[1], l[2], l[3]);
  }

  Quad lerp(Quad o, double t) => Quad(
        tl.lerp(o.tl, t),
        tr.lerp(o.tr, t),
        br.lerp(o.br, t),
        bl.lerp(o.bl, t),
      );

  /// Shoelace area (in the same units as the points).
  double get area {
    final p = points;
    var s = 0.0;
    for (var i = 0; i < 4; i++) {
      final a = p[i], b = p[(i + 1) % 4];
      s += a.x * b.y - b.x * a.y;
    }
    return s.abs() / 2;
  }
}

/// Solves the homography H (3x3, row-major, h33 = 1) such that
/// to[i] = H * from[i]. Returns null if the system is degenerate.
List<double>? computeHomography(List<Pt> from, List<Pt> to) {
  final a = List.generate(8, (_) => List<double>.filled(9, 0));
  for (var i = 0; i < 4; i++) {
    final x = from[i].x, y = from[i].y, u = to[i].x, v = to[i].y;
    a[2 * i] = [x, y, 1, 0, 0, 0, -x * u, -y * u, u];
    a[2 * i + 1] = [0, 0, 0, x, y, 1, -x * v, -y * v, v];
  }
  for (var c = 0; c < 8; c++) {
    var p = c;
    for (var r = c + 1; r < 8; r++) {
      if (a[r][c].abs() > a[p][c].abs()) p = r;
    }
    if (a[p][c].abs() < 1e-12) return null;
    final tmp = a[c];
    a[c] = a[p];
    a[p] = tmp;
    for (var r = 0; r < 8; r++) {
      if (r == c) continue;
      final f = a[r][c] / a[c][c];
      if (f == 0) continue;
      for (var k = c; k < 9; k++) {
        a[r][k] -= f * a[c][k];
      }
    }
  }
  return [for (var i = 0; i < 8; i++) a[i][8] / a[i][i], 1.0];
}

/// Flattens the area of [src] bounded by [quad] (normalised coordinates)
/// into an upright rectangle (perspective crop).
RgbImage warpPerspective(RgbImage src, Quad quad, {int maxSide = 2600}) {
  final sw = src.width.toDouble(), sh = src.height.toDouble();
  final tl = quad.tl.scale(sw, sh);
  final tr = quad.tr.scale(sw, sh);
  final br = quad.br.scale(sw, sh);
  final bl = quad.bl.scale(sw, sh);

  var outW = math.max(tl.dist(tr), bl.dist(br));
  var outH = math.max(tl.dist(bl), tr.dist(br));
  final longest = math.max(outW, outH);
  if (longest > maxSide) {
    final s = maxSide / longest;
    outW *= s;
    outH *= s;
  }
  final w = math.max(16, outW.round());
  final h = math.max(16, outH.round());

  final hm = computeHomography(
    [
      const Pt(0, 0),
      Pt(w - 1.0, 0),
      Pt(w - 1.0, h - 1.0),
      Pt(0, h - 1.0),
    ],
    [tl, tr, br, bl],
  );
  if (hm == null) return src;

  final out = Uint8List(w * h * 3);
  final sd = src.data;
  final maxX = src.width - 1, maxY = src.height - 1;
  var o = 0;
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final den = hm[6] * x + hm[7] * y + 1.0;
      var u = (hm[0] * x + hm[1] * y + hm[2]) / den;
      var v = (hm[3] * x + hm[4] * y + hm[5]) / den;
      if (u < 0) u = 0;
      if (v < 0) v = 0;
      if (u > maxX) u = maxX.toDouble();
      if (v > maxY) v = maxY.toDouble();
      final x0 = u.floor(), y0 = v.floor();
      final x1 = x0 < maxX ? x0 + 1 : x0;
      final y1 = y0 < maxY ? y0 + 1 : y0;
      final fx = u - x0, fy = v - y0;
      final i00 = (y0 * src.width + x0) * 3;
      final i10 = (y0 * src.width + x1) * 3;
      final i01 = (y1 * src.width + x0) * 3;
      final i11 = (y1 * src.width + x1) * 3;
      for (var c = 0; c < 3; c++) {
        final top = sd[i00 + c] + (sd[i10 + c] - sd[i00 + c]) * fx;
        final bot = sd[i01 + c] + (sd[i11 + c] - sd[i01 + c]) * fx;
        out[o++] = (top + (bot - top) * fy).round();
      }
    }
  }
  return RgbImage(w, h, out);
}
