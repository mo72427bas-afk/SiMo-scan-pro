import 'dart:math' as math;
import 'dart:typed_data';

import 'geometry.dart';
import 'rgb_image.dart';

/// Document boundary detection (pure Dart, runs on a downscaled grayscale copy):
/// blur -> Otsu threshold -> morphological close -> largest connected region
/// -> extreme corners. Both polarities (bright paper on dark table and the
/// reverse) are tried and the most "rectangular" candidate wins.
class EdgeDetector {
  static Quad? detectRgb(RgbImage image, {int target = 320}) =>
      detectGray(image.toGray(), image.width, image.height, target: target);

  /// [src] may be a camera plane: use [rowStride] / [pixelStride] / [offset]
  /// to read a luminance (or single channel) value for every pixel.
  static Quad? detectGray(
    Uint8List src,
    int w,
    int h, {
    int target = 200,
    int rowStride = 0,
    int pixelStride = 1,
    int offset = 0,
  }) {
    final stride = rowStride == 0 ? w * pixelStride : rowStride;
    final f = math.max(1, math.max(w, h) ~/ target);
    final sw = w ~/ f, sh = h ~/ f;
    if (sw < 16 || sh < 16) return null;

    var g = Uint8List(sw * sh);
    for (var y = 0; y < sh; y++) {
      for (var x = 0; x < sw; x++) {
        var sum = 0;
        for (var dy = 0; dy < f; dy++) {
          final row = offset + (y * f + dy) * stride + x * f * pixelStride;
          for (var dx = 0; dx < f; dx++) {
            sum += src[row + dx * pixelStride];
          }
        }
        g[y * sw + x] = sum ~/ (f * f);
      }
    }
    g = _boxBlur(g, sw, sh);
    final t = _otsu(g);

    _Candidate? best;
    for (final bright in [true, false]) {
      var mask = Uint8List(sw * sh);
      for (var i = 0; i < mask.length; i++) {
        mask[i] = (bright ? g[i] > t : g[i] <= t) ? 1 : 0;
      }
      mask = _morph(mask, sw, sh, 2, dilate: true);
      mask = _morph(mask, sw, sh, 2, dilate: false);
      final c = _largestComponent(mask, sw, sh);
      if (c == null) continue;
      if (best == null || c.score > best.score) best = c;
    }
    return best?.quad;
  }

  static Uint8List _boxBlur(Uint8List g, int w, int h) {
    final tmp = Uint8List(g.length);
    final out = Uint8List(g.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final a = g[y * w + math.max(0, x - 1)];
        final b = g[y * w + x];
        final c = g[y * w + math.min(w - 1, x + 1)];
        tmp[y * w + x] = (a + b + c) ~/ 3;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final a = tmp[math.max(0, y - 1) * w + x];
        final b = tmp[y * w + x];
        final c = tmp[math.min(h - 1, y + 1) * w + x];
        out[y * w + x] = (a + b + c) ~/ 3;
      }
    }
    return out;
  }

  static int _otsu(Uint8List g) {
    final hist = List<int>.filled(256, 0);
    for (final v in g) {
      hist[v]++;
    }
    final total = g.length;
    var sum = 0.0;
    for (var i = 0; i < 256; i++) {
      sum += i * hist[i];
    }
    var sumB = 0.0, wB = 0, best = 0.0, thr = 127;
    for (var i = 0; i < 256; i++) {
      wB += hist[i];
      if (wB == 0) continue;
      final wF = total - wB;
      if (wF == 0) break;
      sumB += i * hist[i];
      final mB = sumB / wB;
      final mF = (sum - sumB) / wF;
      final between = wB.toDouble() * wF * (mB - mF) * (mB - mF);
      if (between > best) {
        best = between;
        thr = i;
      }
    }
    return thr;
  }

  /// Separable dilation (any pixel set) or erosion (all pixels set,
  /// pixels outside the image count as set).
  static Uint8List _morph(Uint8List m, int w, int h, int r,
      {required bool dilate}) {
    final tmp = Uint8List(m.length);
    final out = Uint8List(m.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = dilate ? 0 : 1;
        for (var k = -r; k <= r; k++) {
          final xx = x + k;
          if (xx < 0 || xx >= w) continue;
          final s = m[y * w + xx];
          if (dilate) {
            if (s == 1) {
              v = 1;
              break;
            }
          } else if (s == 0) {
            v = 0;
            break;
          }
        }
        tmp[y * w + x] = v;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = dilate ? 0 : 1;
        for (var k = -r; k <= r; k++) {
          final yy = y + k;
          if (yy < 0 || yy >= h) continue;
          final s = tmp[yy * w + x];
          if (dilate) {
            if (s == 1) {
              v = 1;
              break;
            }
          } else if (s == 0) {
            v = 0;
            break;
          }
        }
        out[y * w + x] = v;
      }
    }
    return out;
  }

  static _Candidate? _largestComponent(Uint8List mask, int w, int h) {
    final stack = Int32List(w * h);
    int bestArea = 0;
    List<Pt>? bestCorners;

    for (var start = 0; start < mask.length; start++) {
      if (mask[start] != 1) continue;
      var sp = 0;
      stack[sp++] = start;
      mask[start] = 2;
      var area = 0;
      var minS = 1 << 30, maxS = -(1 << 30), minD = 1 << 30, maxD = -(1 << 30);
      var pTl = 0, pBr = 0, pTr = 0, pBl = 0;
      while (sp > 0) {
        final idx = stack[--sp];
        final x = idx % w, y = idx ~/ w;
        area++;
        final s = x + y, d = x - y;
        if (s < minS) {
          minS = s;
          pTl = idx;
        }
        if (s > maxS) {
          maxS = s;
          pBr = idx;
        }
        if (d > maxD) {
          maxD = d;
          pTr = idx;
        }
        if (d < minD) {
          minD = d;
          pBl = idx;
        }
        if (x > 0 && mask[idx - 1] == 1) {
          mask[idx - 1] = 2;
          stack[sp++] = idx - 1;
        }
        if (x < w - 1 && mask[idx + 1] == 1) {
          mask[idx + 1] = 2;
          stack[sp++] = idx + 1;
        }
        if (y > 0 && mask[idx - w] == 1) {
          mask[idx - w] = 2;
          stack[sp++] = idx - w;
        }
        if (y < h - 1 && mask[idx + w] == 1) {
          mask[idx + w] = 2;
          stack[sp++] = idx + w;
        }
      }
      if (area > bestArea) {
        bestArea = area;
        Pt p(int i) => Pt((i % w + 0.5) / w, (i ~/ w + 0.5) / h);
        bestCorners = [p(pTl), p(pTr), p(pBr), p(pBl)];
      }
    }
    if (bestCorners == null) return null;

    final quad = Quad(
        bestCorners[0], bestCorners[1], bestCorners[2], bestCorners[3]);
    final quadArea = quad.area; // normalised, frame = 1.0
    if (quadArea < 0.10 || quadArea > 0.98) return null;
    final fill = (bestArea / (w * h)) / quadArea;
    if (fill < 0.6) return null;
    // Reject degenerate (very thin) shapes.
    final minSide = math.min(
      math.min(quad.tl.dist(quad.tr), quad.bl.dist(quad.br)),
      math.min(quad.tl.dist(quad.bl), quad.tr.dist(quad.br)),
    );
    if (minSide < 0.12) return null;
    return _Candidate(quad, fill * math.sqrt(quadArea));
  }
}

class _Candidate {
  _Candidate(this.quad, this.score);
  final Quad quad;
  final double score;
}
