import 'dart:math' as math;
import 'dart:typed_data';

import 'geometry.dart';
import 'rgb_image.dart';

/// Document boundary detection (pure Dart, runs on a downscaled grayscale copy):
/// blur -> Otsu threshold -> morphological close -> largest connected region
/// -> extreme corners. Both polarities (bright paper on dark table and the
/// reverse) are tried and the most "rectangular" candidate wins.
class EdgeDetector {
  static Quad? detectRgb(RgbImage image, {int target = 320}) =>
      detectGray(image.toGray(), image.width, image.height, target: target);

  /// [src] may be a camera plane: use [rowStride] / [pixelStride] / [offset]
  /// to read a luminance (or single channel) value for every pixel.
  static Quad? detectGray(
    Uint8List src,
    int w,
    int h, {
    int target = 200,
    int rowStride = 0,
    int pixelStride = 1,
    int offset = 0,
  }) {
    final stride = rowStride == 0 ? w * pixelStride : rowStride;
    final f = math.max(1, math.max(w, h) ~/ target);
    final sw = w ~/ f, sh = h ~/ f;
    if (sw < 16 || sh < 16) return null;

    var g = Uint8List(sw * sh);
    for (var y = 0; y < sh; y++) {
      for (var x = 0; x < sw; x++) {
        var sum = 0;
        for (var dy = 0; dy < f; dy++) {
          final row = offset + (y * f + dy) * stride + x * f * pixelStride;
          for (var dx = 0; dx < f; dx++) {
            sum += src[row + dx * pixelStride];
          }
        }
        g[y * sw + x] = sum ~/ (f * f);
      }
    }
    g = _boxBlur(g, sw, sh);
    return _detectLines(g, sw, sh) ?? _detectRegion(g, sw, sh);
  }

  // -------------------------------------------------------------------
  // Method 1: straight document edges (Sobel + Hough + best quadrilateral).
  // Works on bright tables and with shadows where brightness alone fails.
  // -------------------------------------------------------------------
  static const _nt = 90; // theta bins, 2 degrees each

  static Quad? _detectLines(Uint8List g, int w, int h, {int k = 16}) {
    int at(int x, int y) => g[y.clamp(0, h - 1) * w + x.clamp(0, w - 1)];
    final n = w * h;
    final gx = Float32List(n), gy = Float32List(n), mag = Float32List(n);
    final hist = List<int>.filled(2048, 0);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final sx = (at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1)) -
            (at(x - 1, y - 1) + 2 * at(x - 1, y) + at(x - 1, y + 1));
        final sy = (at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1)) -
            (at(x - 1, y - 1) + 2 * at(x, y - 1) + at(x + 1, y - 1));
        final i = y * w + x;
        gx[i] = sx.toDouble();
        gy[i] = sy.toDouble();
        final m = math.sqrt((sx * sx + sy * sy).toDouble());
        mag[i] = m;
        hist[math.min(2047, m.round())]++;
      }
    }
    var acc88 = 0, p88 = 0;
    for (var v = 0; v < 2048; v++) {
      acc88 += hist[v];
      if (acc88 >= n * 0.88) {
        p88 = v;
        break;
      }
    }
    final thr = math.max(p88.toDouble(), 20.0);

    final edge = Uint8List(n);
    for (var i = 0; i < n; i++) {
      if (mag[i] > thr) edge[i] = 1;
    }
    // 1px dilated copy for tolerant support tests.
    final dil = Uint8List(n);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = 0;
        for (var dy = -1; dy <= 1 && v == 0; dy++) {
          for (var dx = -1; dx <= 1; dx++) {
            final xx = x + dx, yy = y + dy;
            if (xx >= 0 && xx < w && yy >= 0 && yy < h && edge[yy * w + xx] == 1) {
              v = 1;
              break;
            }
          }
        }
        dil[y * w + x] = v;
      }
    }

    // Hough accumulator over (theta, rho) using the gradient direction.
    final diag = math.sqrt((w * w + h * h).toDouble()).floor() + 2;
    final stride = 2 * diag + 1;
    final cosT = List<double>.generate(_nt, (t) => math.cos(t * 2 * math.pi / 180));
    final sinT = List<double>.generate(_nt, (t) => math.sin(t * 2 * math.pi / 180));
    var acc = Float64List(_nt * stride);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final i = y * w + x;
        if (edge[i] == 0) continue;
        final ang = math.atan2(gy[i], gx[i]) * 180 / math.pi;
        final base = (ang / 2).round();
        for (var dt = -1; dt <= 1; dt++) {
          final t = (((base + dt) % _nt) + _nt) % _nt;
          final rho = (x * cosT[t] + y * sinT[t]).round() + diag;
          acc[t * stride + rho] += mag[i] * (dt == 0 ? 1.0 : 0.5);
        }
      }
    }
    final sm = Float64List(_nt * stride);
    for (var t = 0; t < _nt; t++) {
      for (var r = 0; r < stride; r++) {
        final a = r > 0 ? acc[t * stride + r - 1] : 0.0;
        final c = r < stride - 1 ? acc[t * stride + r + 1] : 0.0;
        sm[t * stride + r] = (a + 2 * acc[t * stride + r] + c) / 4;
      }
    }
    acc = sm;

    final lines = <_Line>[];
    for (var it = 0; it < k; it++) {
      var best = 0.0, bi = -1;
      for (var i = 0; i < acc.length; i++) {
        if (acc[i] > best) {
          best = acc[i];
          bi = i;
        }
      }
      if (bi < 0) break;
      final t = bi ~/ stride, r = bi % stride;
      lines.add(_Line(t * 2.0, (r - diag).toDouble()));
      for (var dt = -4; dt <= 4; dt++) {
        final tt = (((t + dt) % _nt) + _nt) % _nt;
        for (var rr = math.max(0, r - 6); rr <= math.min(stride - 1, r + 6); rr++) {
          acc[tt * stride + rr] = 0;
        }
      }
    }

    double adiff(double a, double b) {
      final d = (a - b).abs() % 180;
      return math.min(d, 180 - d);
    }

    // Circular mean of two line angles (mod 180).
    double midAngle(double a, double b) {
      final ra = a * math.pi / 90, rb = b * math.pi / 90;
      var m = math.atan2(math.sin(ra) + math.sin(rb), math.cos(ra) + math.cos(rb));
      m = m * 90 / math.pi;
      return m < 0 ? m + 180 : m;
    }

    Pt? intersect(_Line l1, _Line l2) {
      final t1 = l1.theta * math.pi / 180, t2 = l2.theta * math.pi / 180;
      final det = math.cos(t1) * math.sin(t2) - math.sin(t1) * math.cos(t2);
      if (det.abs() < 1e-3) return null;
      final x = (l1.rho * math.sin(t2) - math.sin(t1) * l2.rho) / det;
      final y = (math.cos(t1) * l2.rho - math.cos(t2) * l1.rho) / det;
      return Pt(x, y);
    }

    double support(Pt p, Pt q) {
      final len = math.max((q.x - p.x).abs(), (q.y - p.y).abs()).floor();
      if (len < 4) return 0;
      var inside = 0, hit = 0;
      for (var i = 0; i < len; i++) {
        final t = i / (len - 1);
        final x = (p.x + (q.x - p.x) * t).round();
        final y = (p.y + (q.y - p.y) * t).round();
        if (x < 0 || x >= w || y < 0 || y >= h) continue;
        inside++;
        hit += dil[y * w + x];
      }
      if (inside < len * 0.5) return 0;
      return (hit / inside) * (inside / len);
    }

    final cnt = lines.length;
    double bestScore = -1;
    List<Pt>? bestPts;
    for (var a = 0; a < cnt; a++) {
      for (var b = a + 1; b < cnt; b++) {
        if (adiff(lines[a].theta, lines[b].theta) > 25) continue;
        final mid1 = midAngle(lines[a].theta, lines[b].theta);
        for (var c = a + 1; c < cnt; c++) {
          if (c == b) continue;
          for (var d = c + 1; d < cnt; d++) {
            if (d == b) continue;
            if (adiff(lines[c].theta, lines[d].theta) > 25) continue;
            final between = adiff(mid1, midAngle(lines[c].theta, lines[d].theta));
            if (between < 55 || between > 90) continue;
            final ps = [
              intersect(lines[a], lines[c]),
              intersect(lines[a], lines[d]),
              intersect(lines[b], lines[d]),
              intersect(lines[b], lines[c]),
            ];
            if (ps.any((p) => p == null)) continue;
            final q = Quad.fromUnordered(ps.cast<Pt>()).points;
            var out = false;
            for (final p in q) {
              if (p.x < -0.04 * w || p.x > 1.04 * w || p.y < -0.04 * h || p.y > 1.04 * h) {
                out = true;
              }
            }
            if (out) continue;
            final area = Quad(q[0], q[1], q[2], q[3]).area / (w * h);
            if (area < 0.12 || area > 0.99) continue;
            var minSup = 1.0, sumSup = 0.0;
            for (var i = 0; i < 4; i++) {
              final s = support(q[i], q[(i + 1) % 4]);
              minSup = math.min(minSup, s);
              sumSup += s;
            }
            if (minSup < 0.45) continue;
            final score = (sumSup / 4) * (0.6 + 0.4 * math.sqrt(area)) + 0.15 * minSup;
            if (score > bestScore) {
              bestScore = score;
              bestPts = q;
            }
          }
        }
      }
    }
    if (bestPts == null) return null;
    final fin = bestPts;
    Pt norm(Pt p) => Pt(p.x / w, p.y / h);
    return Quad(norm(fin[0]), norm(fin[1]), norm(fin[2]), norm(fin[3]));
  }

  // -------------------------------------------------------------------
  // Method 2 (fallback): brightest/darkest region (Otsu) -> corners.
  // -------------------------------------------------------------------
  static Quad? _detectRegion(Uint8List g, int sw, int sh) {
    final t = _otsu(g);

    _Candidate? best;
    for (final bright in [true, false]) {
      var mask = Uint8List(sw * sh);
      for (var i = 0; i < mask.length; i++) {
        mask[i] = (bright ? g[i] > t : g[i] <= t) ? 1 : 0;
      }
      mask = _morph(mask, sw, sh, 2, dilate: true);
      mask = _morph(mask, sw, sh, 2, dilate: false);
      final c = _largestComponent(mask, sw, sh);
      if (c == null) continue;
      if (best == null || c.score > best.score) best = c;
    }
    return best?.quad;
  }

  static Uint8List _boxBlur(Uint8List g, int w, int h) {
    final tmp = Uint8List(g.length);
    final out = Uint8List(g.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final a = g[y * w + math.max(0, x - 1)];
        final b = g[y * w + x];
        final c = g[y * w + math.min(w - 1, x + 1)];
        tmp[y * w + x] = (a + b + c) ~/ 3;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final a = tmp[math.max(0, y - 1) * w + x];
        final b = tmp[y * w + x];
        final c = tmp[math.min(h - 1, y + 1) * w + x];
        out[y * w + x] = (a + b + c) ~/ 3;
      }
    }
    return out;
  }

  static int _otsu(Uint8List g) {
    final hist = List<int>.filled(256, 0);
    for (final v in g) {
      hist[v]++;
    }
    final total = g.length;
    var sum = 0.0;
    for (var i = 0; i < 256; i++) {
      sum += i * hist[i];
    }
    var sumB = 0.0, wB = 0, best = 0.0, thr = 127;
    for (var i = 0; i < 256; i++) {
      wB += hist[i];
      if (wB == 0) continue;
      final wF = total - wB;
      if (wF == 0) break;
      sumB += i * hist[i];
      final mB = sumB / wB;
      final mF = (sum - sumB) / wF;
      final between = wB.toDouble() * wF * (mB - mF) * (mB - mF);
      if (between > best) {
        best = between;
        thr = i;
      }
    }
    return thr;
  }

  /// Separable dilation (any pixel set) or erosion (all pixels set,
  /// pixels outside the image count as set).
  static Uint8List _morph(Uint8List m, int w, int h, int r,
      {required bool dilate}) {
    final tmp = Uint8List(m.length);
    final out = Uint8List(m.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = dilate ? 0 : 1;
        for (var k = -r; k <= r; k++) {
          final xx = x + k;
          if (xx < 0 || xx >= w) continue;
          final s = m[y * w + xx];
          if (dilate) {
            if (s == 1) {
              v = 1;
              break;
            }
          } else if (s == 0) {
            v = 0;
            break;
          }
        }
        tmp[y * w + x] = v;
      }
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = dilate ? 0 : 1;
        for (var k = -r; k <= r; k++) {
          final yy = y + k;
          if (yy < 0 || yy >= h) continue;
          final s = tmp[yy * w + x];
          if (dilate) {
            if (s == 1) {
              v = 1;
              break;
            }
          } else if (s == 0) {
            v = 0;
            break;
          }
        }
        out[y * w + x] = v;
      }
    }
    return out;
  }

  static _Candidate? _largestComponent(Uint8List mask, int w, int h) {
    final stack = Int32List(w * h);
    int bestArea = 0;
    List<Pt>? bestCorners;

    for (var start = 0; start < mask.length; start++) {
      if (mask[start] != 1) continue;
      var sp = 0;
      stack[sp++] = start;
      mask[start] = 2;
      var area = 0;
      var minS = 1 << 30, maxS = -(1 << 30), minD = 1 << 30, maxD = -(1 << 30);
      var pTl = 0, pBr = 0, pTr = 0, pBl = 0;
      while (sp > 0) {
        final idx = stack[--sp];
        final x = idx % w, y = idx ~/ w;
        area++;
        final s = x + y, d = x - y;
        if (s < minS) {
          minS = s;
          pTl = idx;
        }
        if (s > maxS) {
          maxS = s;
          pBr = idx;
        }
        if (d > maxD) {
          maxD = d;
          pTr = idx;
        }
        if (d < minD) {
          minD = d;
          pBl = idx;
        }
        if (x > 0 && mask[idx - 1] == 1) {
          mask[idx - 1] = 2;
          stack[sp++] = idx - 1;
        }
        if (x < w - 1 && mask[idx + 1] == 1) {
          mask[idx + 1] = 2;
          stack[sp++] = idx + 1;
        }
        if (y > 0 && mask[idx - w] == 1) {
          mask[idx - w] = 2;
          stack[sp++] = idx - w;
        }
        if (y < h - 1 && mask[idx + w] == 1) {
          mask[idx + w] = 2;
          stack[sp++] = idx + w;
        }
      }
      if (area > bestArea) {
        bestArea = area;
        Pt p(int i) => Pt((i % w + 0.5) / w, (i ~/ w + 0.5) / h);
        bestCorners = [p(pTl), p(pTr), p(pBr), p(pBl)];
      }
    }
    if (bestCorners == null) return null;

    final quad = Quad(
        bestCorners[0], bestCorners[1], bestCorners[2], bestCorners[3]);
    final quadArea = quad.area; // normalised, frame = 1.0
    if (quadArea < 0.10 || quadArea > 0.98) return null;
    final fill = (bestArea / (w * h)) / quadArea;
    if (fill < 0.6) return null;
    // Reject degenerate (very thin) shapes.
    final minSide = math.min(
      math.min(quad.tl.dist(quad.tr), quad.bl.dist(quad.br)),
      math.min(quad.tl.dist(quad.bl), quad.tr.dist(quad.br)),
    );
    if (minSide < 0.12) return null;
    return _Candidate(quad, fill * math.sqrt(quadArea));
  }
}

class _Candidate {
  _Candidate(this.quad, this.score);
  final Quad quad;
  final double score;
}

class _Line {
  _Line(this.theta, this.rho);
  final double theta; // degrees, 0..178 (normal direction)
  final double rho;
}
