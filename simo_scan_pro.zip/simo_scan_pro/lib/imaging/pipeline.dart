import 'dart:typed_data';

import 'deskew.dart';
import 'dewarp.dart';
import 'edge_detector.dart';
import 'filters.dart';
import 'geometry.dart';
import 'rgb_image.dart';

/// Top-level functions below are isolate entry points (used with `compute`).
/// Arguments / results are plain maps so they can cross isolate boundaries.

List<double>? _quadArg(dynamic v) =>
    v == null ? null : (v as List).map((e) => (e as num).toDouble()).toList();

/// Decode -> perspective crop -> fingers -> filter -> rotate -> JPEG.
Uint8List renderPageJob(Map<String, dynamic> m) {
  final bytes = m['bytes'] as Uint8List;
  final maxSide = m['maxSide'] as int;
  var cur = RgbImage.decode(bytes)!;
  final q = _quadArg(m['quad']);
  if (q != null) {
    cur = warpPerspective(cur, Quad.fromList(q), maxSide: maxSide);
  } else {
    cur = cur.limitedTo(maxSide);
  }
  if (m['fingers'] == true) cur = Filters.removeFingers(cur);
  final filter = ScanFilter.values[m['filter'] as int];
  final shadow = m['shadow'] == true;
  if (filter == ScanFilter.original) {
    if (shadow) cur = Filters.normalizeIllumination(cur);
  } else {
    // normalise light -> straighten -> clean dark edges -> apply the look
    if (shadow) cur = Filters.normalizeIllumination(cur);
    cur = Deskew.apply(cur);
    cur = Filters.cleanBorders(cur);
    cur = Filters.applyNormalized(cur, filter);
  }
  if (m['flatten'] == true) cur = Dewarp.flatten(cur);
  cur = cur.rotated(m['rotation'] as int);
  return cur.encodeJpg(quality: m['quality'] as int);
}

/// Normalises a raw capture/import: bakes EXIF, limits size, detects the
/// document quad. Returns {bytes, w, h, quad}.
Map<String, dynamic> importJob(Map<String, dynamic> m) {
  var im = RgbImage.decode(m['bytes'] as Uint8List,
      maxSide: (m['maxSide'] as int?) ?? 3600)!;
  final quad = EdgeDetector.detectRgb(im) ?? Quad.full(inset: 0.03);
  return {
    'bytes': im.encodeJpg(quality: 92),
    'w': im.width,
    'h': im.height,
    'quad': quad.toList(),
  };
}

/// Live preview detection on a camera frame.
List<double>? liveDetectJob(Map<String, dynamic> m) {
  final q = EdgeDetector.detectGray(
    m['bytes'] as Uint8List,
    m['w'] as int,
    m['h'] as int,
    target: 160,
    rowStride: m['rowStride'] as int,
    pixelStride: m['pixelStride'] as int,
    offset: m['offset'] as int,
  );
  return q?.toList();
}

/// Splits a photographed book spread into two pages. Returns a list of
/// {bytes, w, h, quad} maps ordered for reading.
List<Map<String, dynamic>> bookJob(Map<String, dynamic> m) {
  final im = RgbImage.decode(m['bytes'] as Uint8List, maxSide: 4000)!;
  final rtl = m['rtl'] == true;
  final half = im.width ~/ 2;
  final overlap = (im.width * 0.01).round();
  final left = im.cropRect(0, 0, half + overlap, im.height);
  final right = im.cropRect(half - overlap, 0, im.width - half + overlap, im.height);
  final parts = rtl ? [right, left] : [left, right];
  return [
    for (final p in parts)
      {
        'bytes': p.encodeJpg(quality: 92),
        'w': p.width,
        'h': p.height,
        'quad': (EdgeDetector.detectRgb(p) ?? Quad.full(inset: 0.02)).toList(),
      }
  ];
}

/// Puts front and back of an ID card on one A4 sheet (200 dpi).
Uint8List idCardJob(Map<String, dynamic> m) {
  const a4w = 1654, a4h = 2339;
  final sheet = RgbImage.blank(a4w, a4h);
  final cards = [
    RgbImage.decode(m['front'] as Uint8List)!,
    RgbImage.decode(m['back'] as Uint8List)!,
  ];
  const cardW = 1000;
  for (var i = 0; i < 2; i++) {
    final c = cards[i];
    final ch = (c.height * cardW / c.width).round().clamp(50, 1000);
    final r = c.resized(cardW, ch);
    final x0 = (a4w - cardW) ~/ 2;
    final y0 = i == 0 ? 260 : 1260;
    for (var y = 0; y < r.height && y0 + y < a4h; y++) {
      sheet.data.setRange(((y0 + y) * a4w + x0) * 3,
          ((y0 + y) * a4w + x0 + cardW) * 3, r.data, y * cardW * 3);
    }
  }
  return sheet.encodeJpg(quality: 92);
}

/// Recompress a page image for PDF export. Returns {bytes, w, h}.
Map<String, dynamic> recompressJob(Map<String, dynamic> m) {
  final im = RgbImage.decode(m['bytes'] as Uint8List)!
      .limitedTo(m['maxSide'] as int);
  return {
    'bytes': im.encodeJpg(quality: m['quality'] as int),
    'w': im.width,
    'h': im.height,
  };
}
