import 'dart:typed_data';

import 'package:image/image.dart' as img;

/// Minimal interleaved RGB bitmap used by all processing code.
/// Pure Dart, so every operation can run inside an isolate.
class RgbImage {
  RgbImage(this.width, this.height, this.data);

  final int width;
  final int height;
  final Uint8List data;

  factory RgbImage.blank(int w, int h, {int fill = 255}) {
    final d = Uint8List(w * h * 3);
    if (fill != 0) d.fillRange(0, d.length, fill);
    return RgbImage(w, h, d);
  }

  factory RgbImage.fromImage(img.Image src) {
    final im = (src.numChannels == 3 &&
            src.format == img.Format.uint8 &&
            !src.hasPalette)
        ? src
        : src.convert(format: img.Format.uint8, numChannels: 3);
    final bytes = im.getBytes(order: img.ChannelOrder.rgb);
    return RgbImage(im.width, im.height, Uint8List.fromList(bytes));
  }

  factory RgbImage.fromRgba(int w, int h, Uint8List rgba) {
    final d = Uint8List(w * h * 3);
    var j = 0;
    for (var i = 0; i < w * h; i++) {
      d[j++] = rgba[i * 4];
      d[j++] = rgba[i * 4 + 1];
      d[j++] = rgba[i * 4 + 2];
    }
    return RgbImage(w, h, d);
  }

  /// Decodes JPEG/PNG bytes, applies EXIF orientation and optionally limits
  /// the longest side to [maxSide].
  static RgbImage? decode(Uint8List bytes, {int? maxSide}) {
    var im = img.decodeImage(bytes);
    if (im == null) return null;
    im = img.bakeOrientation(im);
    if (maxSide != null && (im.width > maxSide || im.height > maxSide)) {
      final landscape = im.width >= im.height;
      im = img.copyResize(
        im,
        width: landscape ? maxSide : null,
        height: landscape ? null : maxSide,
        interpolation: img.Interpolation.average,
      );
    }
    return RgbImage.fromImage(im);
  }

  img.Image toImage() => img.Image.fromBytes(
        width: width,
        height: height,
        bytes: Uint8List.fromList(data).buffer,
        numChannels: 3,
      );

  Uint8List encodeJpg({int quality = 90}) =>
      Uint8List.fromList(img.encodeJpg(toImage(), quality: quality));

  RgbImage resized(int w, int h) {
    final out = img.copyResize(
      toImage(),
      width: w,
      height: h,
      interpolation: img.Interpolation.average,
    );
    return RgbImage.fromImage(out);
  }

  /// Scales so that the longest side is at most [maxSide].
  RgbImage limitedTo(int maxSide) {
    final longest = width > height ? width : height;
    if (longest <= maxSide) return this;
    final s = maxSide / longest;
    return resized((width * s).round(), (height * s).round());
  }

  RgbImage cropRect(int x, int y, int w, int h) {
    final x0 = x.clamp(0, width - 1);
    final y0 = y.clamp(0, height - 1);
    final cw = w.clamp(1, width - x0);
    final ch = h.clamp(1, height - y0);
    final out = Uint8List(cw * ch * 3);
    for (var yy = 0; yy < ch; yy++) {
      final srcStart = ((y0 + yy) * width + x0) * 3;
      out.setRange(yy * cw * 3, (yy + 1) * cw * 3, data, srcStart);
    }
    return RgbImage(cw, ch, out);
  }

  Uint8List toGray() {
    final g = Uint8List(width * height);
    var j = 0;
    for (var i = 0; i < g.length; i++) {
      g[i] = (data[j] * 77 + data[j + 1] * 150 + data[j + 2] * 29) >> 8;
      j += 3;
    }
    return g;
  }

  /// Rotates clockwise by 90° * [quarterTurns].
  RgbImage rotated(int quarterTurns) {
    final t = ((quarterTurns % 4) + 4) % 4;
    if (t == 0) return this;
    final nw = t == 2 ? width : height;
    final nh = t == 2 ? height : width;
    final out = Uint8List(nw * nh * 3);
    for (var y = 0; y < height; y++) {
      for (var x = 0; x < width; x++) {
        int nx, ny;
        if (t == 1) {
          nx = height - 1 - y;
          ny = x;
        } else if (t == 2) {
          nx = width - 1 - x;
          ny = height - 1 - y;
        } else {
          nx = y;
          ny = width - 1 - x;
        }
        final s = (y * width + x) * 3;
        final d = (ny * nw + nx) * 3;
        out[d] = data[s];
        out[d + 1] = data[s + 1];
        out[d + 2] = data[s + 2];
      }
    }
    return RgbImage(nw, nh, out);
  }
}
