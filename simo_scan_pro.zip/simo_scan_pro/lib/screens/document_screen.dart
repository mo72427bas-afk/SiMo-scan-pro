import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../imaging/filters.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/export_service.dart';
import '../services/library_service.dart';
import '../services/page_factory.dart';
import '../services/pdf_writer.dart';
import 'camera_screen.dart';
import 'editor_screen.dart';

Future<String?> askText(BuildContext context, String title, {String initial = ''}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl,
        autofocus: true,
        decoration: InputDecoration(labelText: context.tr('name')),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: Text(context.tr('cancel'))),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, ctl.text.trim()),
            child: Text(context.tr('ok'))),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context) async =>
    await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(context.tr('deleteConfirm')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(context.tr('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(context.tr('delete'))),
        ],
      ),
    ) ??
    false;

class DocumentScreen extends StatelessWidget {
  const DocumentScreen({super.key, required this.docId});
  final String docId;

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryService>();
    final doc = lib.doc(docId);
    if (doc == null) return const Scaffold();

    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: () async {
            final n = await askText(context, context.tr('rename'), initial: doc.name);
            if (n != null && n.isNotEmpty) lib.renameDoc(doc.id, n);
          },
          child: Text(doc.name, overflow: TextOverflow.ellipsis),
        ),
        actions: [
          PopupMenuButton<ScanFilter>(
            icon: const Icon(Icons.auto_fix_high),
            tooltip: context.tr('bulkFilter'),
            enabled: doc.pages.isNotEmpty,
            onSelected: (f) => _bulk(context, doc, f),
            itemBuilder: (_) => [
              PopupMenuItem(value: ScanFilter.magic, child: Text(context.tr('magicColor'))),
              PopupMenuItem(value: ScanFilter.bw, child: Text(context.tr('bw'))),
              PopupMenuItem(value: ScanFilter.gray, child: Text(context.tr('gray'))),
              PopupMenuItem(value: ScanFilter.original, child: Text(context.tr('original'))),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.ios_share),
            tooltip: context.tr('export'),
            onPressed: doc.pages.isEmpty ? null : () => _exportSheet(context, doc),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add_a_photo),
        label: Text(context.tr('addPage')),
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => CameraScreen(docId: doc.id))),
      ),
      body: doc.pages.isEmpty
          ? Center(child: Text(context.tr('noPages')))
          : ReorderableListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
              buildDefaultDragHandles: false,
              itemCount: doc.pages.length,
              onReorder: (o, n) => lib.reorderPages(doc.id, o, n),
              itemBuilder: (ctx, i) {
                final pg = doc.pages[i];
                return Card(
                  key: ValueKey(pg.id),
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(8),
                    leading: SizedBox(
                      width: 64,
                      child: Image.file(
                        lib.fileOf(doc.id, pg.procFile),
                        fit: BoxFit.cover,
                        cacheWidth: 300,
                        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image),
                      ),
                    ),
                    title: Text('${i + 1}'),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => EditorScreen(docId: doc.id, pageId: pg.id),
                      ),
                    ),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          if (await confirm(context)) lib.removePage(doc.id, i);
                        },
                      ),
                      ReorderableDragStartListener(
                        index: i,
                        child: const Padding(
                          padding: EdgeInsets.all(8),
                          child: Icon(Icons.drag_handle),
                        ),
                      ),
                    ]),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _bulk(BuildContext context, DocModel doc, ScanFilter f) async {
    final factory = context.read<PageFactory>();
    final progress = ValueNotifier<String>('...');
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          content: ValueListenableBuilder<String>(
            valueListenable: progress,
            builder: (_, v, __) => Row(children: [
              const CircularProgressIndicator(),
              const SizedBox(width: 16),
              Text('${context.tr('working')} $v'),
            ]),
          ),
        ),
      ),
    );
    try {
      await factory.reprocess(doc,
          filter: f, onProgress: (i, n) => progress.value = '$i/$n');
    } finally {
      if (context.mounted) Navigator.pop(context);
    }
  }

  void _exportSheet(BuildContext context, DocModel doc) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _ExportSheet(doc: doc),
    );
  }
}

class _ExportSheet extends StatefulWidget {
  const _ExportSheet({required this.doc});
  final DocModel doc;
  @override
  State<_ExportSheet> createState() => _ExportSheetState();
}

enum _Fmt { pdf, jpg, txt, docx }

class _ExportSheetState extends State<_ExportSheet> {
  _Fmt _fmt = _Fmt.pdf;
  PdfQuality _q = PdfQuality.high;
  final _pw = TextEditingController();
  bool _busy = false;
  String _progress = '';
  String? _pwError;
  List<File>? _files;

  String get _mime => switch (_fmt) {
        _Fmt.pdf => 'application/pdf',
        _Fmt.jpg => 'image/jpeg',
        _Fmt.txt => 'text/plain',
        _Fmt.docx =>
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      };

  Future<void> _run() async {
    final svc = context.read<ExportService>();
    if (_fmt == _Fmt.pdf &&
        _pw.text.isNotEmpty &&
        !PdfWriter.isValidPassword(_pw.text)) {
      setState(() => _pwError = context.tr('pwInvalid'));
      return;
    }
    setState(() {
      _busy = true;
      _pwError = null;
      _progress = context.tr('exporting');
    });
    try {
      final List<File> files;
      switch (_fmt) {
        case _Fmt.pdf:
          files = [
            await svc.toPdf(widget.doc,
                quality: _q, password: _pw.text.isEmpty ? null : _pw.text)
          ];
        case _Fmt.jpg:
          files = await svc.toJpgs(widget.doc);
        case _Fmt.txt:
          files = [
            await svc.toTxt(widget.doc,
                onProgress: (i, n) => setState(() => _progress = 'OCR $i/$n'))
          ];
        case _Fmt.docx:
          files = [
            await svc.toDocx(widget.doc,
                onProgress: (i, n) => setState(() => _progress = 'OCR $i/$n'))
          ];
      }
      if (!mounted) return;
      setState(() {
        _busy = false;
        _files = files;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(context.tr('ocrFail'))));
    }
  }

  Future<void> _share() async {
    final files = _files!;
    await Share.shareXFiles(
      [for (final f in files) XFile(f.path, mimeType: _mime)],
      subject: widget.doc.name,
    );
  }

  Future<void> _save() async {
    var saved = 0;
    for (final f in _files!) {
      try {
        final r = await FlutterFileDialog.saveFile(
          params: SaveFileDialogParams(
              sourceFilePath: f.path, fileName: p.basename(f.path)),
        );
        if (r != null) saved++;
      } catch (_) {}
    }
    if (!mounted) return;
    if (saved > 0) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(context.tr('saved'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: SingleChildScrollView(
          child: _files != null ? _doneView(context) : _formView(context),
        ),
      ),
    );
  }

  Widget _doneView(BuildContext context) {
    final files = _files!;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.check_circle, color: Colors.green, size: 48),
      const SizedBox(height: 8),
      Text(context.tr('exportDone'),
          style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 4),
      Text(
        files.length == 1
            ? p.basename(files.first.path)
            : '${files.length} ${context.tr('files')}',
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          icon: const Icon(Icons.share),
          label: Text(context.tr('share')),
          onPressed: _share,
        ),
      ),
      const SizedBox(height: 8),
      SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          icon: const Icon(Icons.save_alt),
          label: Text(context.tr('saveDevice')),
          onPressed: _save,
        ),
      ),
      TextButton(
        onPressed: () => setState(() => _files = null),
        child: Text(context.tr('back')),
      ),
    ]);
  }

  Widget _formView(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Text(context.tr('export'), style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      SegmentedButton<_Fmt>(
        segments: [
          ButtonSegment(value: _Fmt.pdf, label: Text(context.tr('exportPdf'))),
          const ButtonSegment(value: _Fmt.jpg, label: Text('JPG')),
          const ButtonSegment(value: _Fmt.txt, label: Text('TXT')),
          const ButtonSegment(value: _Fmt.docx, label: Text('DOCX')),
        ],
        selected: {_fmt},
        onSelectionChanged: (s) => setState(() => _fmt = s.first),
      ),
      if (_fmt == _Fmt.pdf) ...[
        const SizedBox(height: 16),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(context.tr('quality')),
        ),
        RadioGroupColumn(
          value: _q,
          onChanged: (v) => setState(() => _q = v),
          items: {
            PdfQuality.low: context.tr('qLow'),
            PdfQuality.medium: context.tr('qMed'),
            PdfQuality.high: context.tr('qHigh'),
          },
        ),
        TextField(
          controller: _pw,
          obscureText: true,
          decoration: InputDecoration(
            labelText: context.tr('password'),
            errorText: _pwError,
            prefixIcon: const Icon(Icons.lock_outline),
          ),
        ),
      ],
      const SizedBox(height: 8),
      Text(context.tr('noWatermark'), style: Theme.of(context).textTheme.bodySmall),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          icon: _busy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.file_download),
          label: Text(_busy ? _progress : context.tr('export')),
          onPressed: _busy ? null : _run,
        ),
      ),
    ]);
  }
}

/// Small radio list that avoids the deprecated Radio.groupValue API.
class RadioGroupColumn<T> extends StatelessWidget {
  const RadioGroupColumn(
      {super.key, required this.value, required this.onChanged, required this.items});
  final T value;
  final ValueChanged<T> onChanged;
  final Map<T, String> items;

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      for (final e in items.entries)
        ListTile(
          dense: true,
          title: Text(e.value),
          leading: Icon(e.key == value
              ? Icons.radio_button_checked
              : Icons.radio_button_unchecked),
          onTap: () => onChanged(e.key),
        ),
    ]);
  }
}

