import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../imaging/filters.dart';
import '../imaging/geometry.dart';
import '../imaging/pipeline.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/compositor.dart';
import '../services/library_service.dart';
import '../services/ocr_service.dart';
import '../services/page_factory.dart';
import '../widgets/crop_canvas.dart';
import '../widgets/signature_pad.dart';

enum _Tool { none, eraser }

/// One undo/redo step of everything the user can change in the editor.
class _Snap {
  _Snap({
    required this.quad,
    required this.filter,
    required this.shadow,
    required this.fingers,
    required this.flatten,
    required this.rotation,
    required this.strokes,
    required this.placements,
    required this.watermark,
    required this.cropMode,
  });
  final Quad quad;
  final ScanFilter filter;
  final bool shadow, fingers, flatten, cropMode;
  final int rotation;
  final List<EraseStroke> strokes;
  final List<Placement> placements;
  final String watermark;
}

/// Pro document editor: crop canvas (8 handles + loupe), filters, magic
/// clean, signature, watermark, OCR, eraser and rotation.
class EditorScreen extends StatefulWidget {
  const EditorScreen({
    super.key,
    required this.docId,
    required this.pageId,
    this.startInCrop = false,
  });

  final String docId;
  final String pageId;
  final bool startInCrop;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final LibraryService _lib = context.read<LibraryService>();
  late final PageFactory _factory = context.read<PageFactory>();
  late PageModel _page;
  Uint8List? _orig;
  Uint8List? _preview;
  Uint8List? _cmp;
  String _cmpKey = '';
  bool _comparing = false;
  bool _holding = false;
  bool _allPages = false;
  double _aspect = 1;

  late Quad _quad;
  late ScanFilter _filter;
  late bool _shadow, _fingers, _flatten;
  late int _rotation;
  bool _cropMode = false;
  _Tool _tool = _Tool.none;
  final OverlayData _overlay = OverlayData();
  EraseStroke? _current;

  final List<_Snap> _undo = [];
  final List<_Snap> _redo = [];

  int _busy = 0;
  int _token = 0;
  String? _ocrText;

  @override
  void initState() {
    super.initState();
    final doc = _lib.doc(widget.docId)!;
    _page = doc.pages.firstWhere((p) => p.id == widget.pageId);
    _quad = _page.quad != null ? Quad.fromList(_page.quad!) : Quad.full();
    _filter = _page.filter;
    _shadow = _page.shadow;
    _fingers = _page.fingers;
    _flatten = _page.flatten;
    _rotation = _page.rotation;
    _cropMode = widget.startInCrop;
    _load();
  }

  Future<void> _load() async {
    _orig = await _lib.fileOf(widget.docId, _page.origFile).readAsBytes();
    if (!_cropMode) {
      await _rerender();
    } else {
      setState(() {});
    }
  }

  Future<void> _rerender() async {
    final token = ++_token;
    setState(() => _busy++);
    try {
      final bytes = await _factory.render(
        _orig!,
        quad: _quad.toList(),
        filter: _filter,
        shadow: _shadow,
        fingers: _fingers,
        flatten: _flatten,
        rotation: _rotation,
        maxSide: PageFactory.previewSide,
        quality: 85,
      );
      final codec = await ui.instantiateImageCodec(bytes);
      final f = (await codec.getNextFrame()).image;
      if (!mounted || token != _token) return;
      setState(() {
        _preview = bytes;
        _aspect = f.width / f.height;
      });
    } finally {
      if (mounted) setState(() => _busy--);
    }
  }

  Future<void> _showCompare(bool on) async {
    _holding = on;
    if (!on) {
      setState(() => _comparing = false);
      return;
    }
    final key = '${_quad.toList()}|$_rotation';
    if (_cmp == null || _cmpKey != key) {
      final bytes = await _factory.render(
        _orig!,
        quad: _quad.toList(),
        filter: ScanFilter.original,
        shadow: false,
        fingers: false,
        flatten: false,
        rotation: _rotation,
        maxSide: PageFactory.previewSide,
        quality: 85,
      );
      _cmp = bytes;
      _cmpKey = key;
    }
    if (mounted && _holding) setState(() => _comparing = true);
  }

  Future<void> _autoDetect() async {
    _push();
    setState(() => _busy++);
    try {
      final r = await compute(importJob, {'bytes': _orig!, 'maxSide': 900});
      setState(() => _quad =
          Quad.fromList((r['quad'] as List).map((e) => (e as num).toDouble()).toList()));
    } finally {
      if (mounted) setState(() => _busy--);
    }
  }

  Future<void> _save() async {
    setState(() => _busy++);
    try {
      var bytes = await _factory.render(
        _orig!,
        quad: _quad.toList(),
        filter: _filter,
        shadow: _shadow,
        fingers: _fingers,
        flatten: _flatten,
        rotation: _rotation,
      );
      bytes = await Compositor.bake(bytes, _overlay);
      await _lib.fileOf(widget.docId, _page.procFile).writeAsBytes(bytes, flush: true);
      _page
        ..quad = _quad.toList()
        ..filter = _filter
        ..shadow = _shadow
        ..fingers = _fingers
        ..flatten = _flatten
        ..rotation = _rotation
        ..ocrText = _ocrText;
      await _lib.commit();
      PaintingBinding.instance.imageCache.clear();
      if (mounted) Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => _busy--);
    }
  }

  // ---- undo / redo ------------------------------------------------------
  _Snap _snap() => _Snap(
        quad: _quad,
        filter: _filter,
        shadow: _shadow,
        fingers: _fingers,
        flatten: _flatten,
        rotation: _rotation,
        cropMode: _cropMode,
        watermark: _overlay.watermark,
        strokes: [for (final s in _overlay.strokes) EraseStroke(List.of(s.points), s.width)],
        placements: [
          for (final p in _overlay.placements)
            Placement(p.png, p.aspect, cx: p.cx, cy: p.cy, w: p.w)
        ],
      );

  /// Call right BEFORE changing anything.
  void _push() {
    _undo.add(_snap());
    if (_undo.length > 60) _undo.removeAt(0);
    _redo.clear();
  }

  void _restore(_Snap s) {
    final renderChanged = s.filter != _filter ||
        s.shadow != _shadow ||
        s.fingers != _fingers ||
        s.flatten != _flatten ||
        s.rotation != _rotation ||
        s.quad != _quad ||
        s.cropMode != _cropMode;
    setState(() {
      _quad = s.quad;
      _filter = s.filter;
      _shadow = s.shadow;
      _fingers = s.fingers;
      _flatten = s.flatten;
      _rotation = s.rotation;
      _cropMode = s.cropMode;
      _overlay.strokes
        ..clear()
        ..addAll(s.strokes);
      _overlay.placements
        ..clear()
        ..addAll(s.placements);
      _overlay.watermark = s.watermark;
    });
    if (renderChanged && !_cropMode) _rerender();
  }

  void _doUndo() {
    if (_undo.isEmpty) return;
    _redo.add(_snap());
    _restore(_undo.removeLast());
  }

  void _doRedo() {
    if (_redo.isEmpty) return;
    _undo.add(_snap());
    _restore(_redo.removeLast());
  }

  Future<void> _applyAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(context.tr('applyAll')),
        content: Text(context.tr('applyAllWarn')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(context.tr('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(context.tr('ok'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await _applyAllCore();
  }

  Future<void> _applyAllCore() async {
    final doc = _lib.doc(widget.docId)!;
    final progress = ValueNotifier<String>('...');
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          content: ValueListenableBuilder<String>(
            valueListenable: progress,
            builder: (_, v, __) => Row(children: [
              const CircularProgressIndicator(),
              const SizedBox(width: 16),
              Text('${context.tr('working')} $v'),
            ]),
          ),
        ),
      ),
    );
    try {
      await _factory.reprocess(
        doc,
        filter: _filter,
        shadow: _shadow,
        fingers: _fingers,
        flatten: _flatten,
        skipId: _page.id,
        onProgress: (i, n) => progress.value = '$i/$n',
      );
    } finally {
      if (mounted) Navigator.pop(context);
    }
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(context.tr('saved'))));
    }
  }

  // ---- tools ------------------------------------------------------------
  void _magicSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, setS) {
        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            SwitchListTile(
              title: Text(context.tr('removeShadow')),
              value: _shadow,
              onChanged: (v) {
                _push();
                setS(() => _shadow = v);
                setState(() {});
                _rerender();
              },
            ),
            SwitchListTile(
              title: Text(context.tr('flatten')),
              value: _flatten,
              onChanged: (v) {
                _push();
                setS(() => _flatten = v);
                setState(() {});
                _rerender();
              },
            ),
            SwitchListTile(
              title: Text(context.tr('removeFingers')),
              value: _fingers,
              onChanged: (v) {
                _push();
                setS(() => _fingers = v);
                setState(() {});
                _rerender();
              },
            ),
          ]),
        );
      }),
    );
  }

  Future<void> _sign() async {
    final r = await showSignaturePad(context);
    if (r == null) return;
    _push();
    setState(() => _overlay.placements.add(Placement(r.png, r.aspect)));
  }

  Future<void> _watermark() async {
    final ctl = TextEditingController(text: _overlay.watermark);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(context.tr('watermark')),
        content: TextField(
          controller: ctl,
          autofocus: true,
          decoration: InputDecoration(hintText: context.tr('watermarkHint')),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, ''),
              child: Text(context.tr('clear'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctl.text),
              child: Text(context.tr('ok'))),
        ],
      ),
    );
    if (v != null && v != _overlay.watermark) {
      _push();
      setState(() => _overlay.watermark = v);
    }
  }

  Future<void> _ocr() async {
    if (_preview == null) return;
    setState(() => _busy++);
    String? text;
    try {
      final bytes = await _factory.render(
        _orig!,
        quad: _quad.toList(),
        filter: ScanFilter.gray,
        shadow: true,
        fingers: _fingers,
        flatten: _flatten,
        rotation: _rotation,
        maxSide: 2200,
      );
      text = await OcrService.recognize(bytes);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(context.tr('ocrFail'))));
      }
    } finally {
      if (mounted) setState(() => _busy--);
    }
    if (text == null || !mounted) return;
    _ocrText = text;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .7,
        builder: (_, sc) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Row(children: [
              Expanded(
                  child: Text(context.tr('ocr'),
                      style: Theme.of(context).textTheme.titleMedium)),
              IconButton(
                icon: const Icon(Icons.copy),
                tooltip: context.tr('copy'),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: text!));
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text(context.tr('copied'))));
                },
              ),
            ]),
            Expanded(
              child: SingleChildScrollView(
                controller: sc,
                child: SelectableText(text!, style: const TextStyle(fontSize: 16, height: 1.5)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ---- eraser gestures --------------------------------------------------
  Offset _norm(Offset local, Size s) =>
      Offset(local.dx / s.width, local.dy / s.height);

  // ---- UI ---------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_cropMode ? context.tr('crop') : context.tr('app')),
        actions: [
          if (_busy > 0)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Center(
                  child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))),
            ),
          IconButton(
            icon: const Icon(Icons.undo),
            tooltip: context.tr('undo'),
            onPressed: _undo.isEmpty || _busy > 0 ? null : _doUndo,
          ),
          IconButton(
            icon: const Icon(Icons.redo),
            tooltip: context.tr('redo'),
            onPressed: _redo.isEmpty || _busy > 0 ? null : _doRedo,
          ),
          if (!_cropMode)
            IconButton(
              icon: const Icon(Icons.check_circle),
              tooltip: context.tr('save'),
              onPressed: _busy > 0 ? null : _save,
            ),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          Expanded(child: _cropMode ? _cropBody() : _editBody()),
          _cropMode ? _cropBar() : _editBars(),
        ]),
      ),
    );
  }

  Widget _cropBody() {
    if (_orig == null) return const Center(child: CircularProgressIndicator());
    return Padding(
      padding: const EdgeInsets.all(20),
      child: CropCanvas(
        image: _orig!,
        aspect: _page.origW / _page.origH,
        quad: _quad,
        onChanged: (q) => setState(() => _quad = q),
        onStart: _push,
      ),
    );
  }

  Widget _cropBar() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Row(children: [
          IconButton.outlined(
            icon: const Icon(Icons.auto_fix_high),
            onPressed: _busy > 0 ? null : _autoDetect,
          ),
          const SizedBox(width: 8),
          IconButton.outlined(
            icon: const Icon(Icons.crop_free),
            onPressed: () {
              _push();
              setState(() => _quad = Quad.full());
            },
          ),
          const SizedBox(width: 12),
          Expanded(
            child: FilledButton.icon(
              icon: const Icon(Icons.check),
              label: Text(context.tr('applyCrop')),
              onPressed: _busy > 0
                  ? null
                  : () {
                      _push();
                      setState(() => _cropMode = false);
                      _rerender();
                    },
            ),
          ),
        ]),
      );

  Widget _editBody() {
    if (_preview == null) return const Center(child: CircularProgressIndicator());
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Center(
        child: AspectRatio(
          aspectRatio: _aspect,
          child: LayoutBuilder(builder: (context, box) {
            final size = Size(box.maxWidth, box.maxHeight);
            return Container(
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(blurRadius: 12, color: Colors.black.withValues(alpha: .25))
              ]),
              child: ClipRect(
                child: Stack(children: [
                  Positioned.fill(
                    child: Image.memory(
                        _comparing && _cmp != null ? _cmp! : _preview!,
                        fit: BoxFit.fill,
                        gaplessPlayback: true),
                  ),
                  Positioned.fill(
                    child: CustomPaint(
                        painter: _StrokePainter(_overlay.strokes, size)),
                  ),
                  if (_overlay.watermark.trim().isNotEmpty)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: Transform.rotate(
                            angle: -0.52,
                            child: Text(
                              _overlay.watermark,
                              style: TextStyle(
                                fontSize: size.width * 0.09,
                                fontWeight: FontWeight.w700,
                                color: Colors.black.withValues(alpha: .18),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  for (final pl in _overlay.placements) _placement(pl, size),
                  if (_tool == _Tool.eraser)
                    Positioned.fill(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onPanStart: (d) => setState(() {
                          _push();
                          _current = EraseStroke([_norm(d.localPosition, size)], 0.04);
                          _overlay.strokes.add(_current!);
                        }),
                        onPanUpdate: (d) => setState(
                            () => _current?.points.add(_norm(d.localPosition, size))),
                        onPanEnd: (_) => _current = null,
                      ),
                    ),
                  PositionedDirectional(
                    top: 6,
                    start: 6,
                    child: Listener(
                      onPointerDown: (_) => _showCompare(true),
                      onPointerUp: (_) => _showCompare(false),
                      onPointerCancel: (_) => _showCompare(false),
                      child: Tooltip(
                        message: context.tr('compare'),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: .55),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.compare,
                              color: Colors.white, size: 20),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _placement(Placement pl, Size size) {
    final wPx = pl.w * size.width;
    final hPx = wPx / pl.aspect;
    return Positioned(
      left: pl.cx * size.width - wPx / 2,
      top: pl.cy * size.height - hPx / 2,
      width: wPx,
      height: hPx,
      child: GestureDetector(
        onScaleStart: (_) {
          _push();
          pl.startW = pl.w;
        },
        onScaleUpdate: (d) => setState(() {
          pl.cx = (pl.cx + d.focalPointDelta.dx / size.width).clamp(0.0, 1.0);
          pl.cy = (pl.cy + d.focalPointDelta.dy / size.height).clamp(0.0, 1.0);
          if (d.scale != 1.0) pl.w = (pl.startW * d.scale).clamp(0.08, 0.95);
        }),
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                  border: Border.all(
                      color: AppColors.blue.withValues(alpha: .6), width: 1.2)),
              child: Image.memory(pl.png, fit: BoxFit.fill),
            ),
          ),
          Positioned(
            right: -10,
            top: -10,
            child: GestureDetector(
              onTap: () {
                _push();
                setState(() => _overlay.placements.remove(pl));
              },
              child: const CircleAvatar(
                  radius: 11,
                  backgroundColor: Colors.red,
                  child: Icon(Icons.close, size: 14, color: Colors.white)),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _editBars() {
    Widget filterChip(ScanFilter f, String key) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: ChoiceChip(
            label: Text(context.tr(key)),
            selected: _filter == f,
            onSelected: (_) async {
              _push();
              setState(() => _filter = f);
              await _rerender();
              if (_allPages && mounted) await _applyAllCore();
            },
          ),
        );

    Widget tool(IconData i, String key, VoidCallback onTap, {bool active = false}) =>
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 78,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: active
                  ? AppColors.blue.withValues(alpha: .15)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(i, color: active ? AppColors.blue : null),
              const SizedBox(height: 4),
              Text(context.tr(key),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11)),
            ]),
          ),
        );

    return Column(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(
        height: 44,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: FilterChip(
                avatar: Icon(Icons.library_add_check,
                    size: 18,
                    color: _allPages ? AppColors.blue : null),
                label: Text(context.tr('applyAll')),
                selected: _allPages,
                onSelected: (v) => setState(() => _allPages = v),
              ),
            ),
            filterChip(ScanFilter.original, 'original'),
            filterChip(ScanFilter.pro, 'magicPro'),
            filterChip(ScanFilter.magic, 'magicColor'),
            filterChip(ScanFilter.lighten, 'lighten'),
            filterChip(ScanFilter.bw, 'bw'),
            filterChip(ScanFilter.gray, 'gray'),
          ],
        ),
      ),
      SizedBox(
        height: 72,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          children: [
            tool(Icons.crop, 'crop', () {
              _push();
              setState(() => _cropMode = true);
            }),
            tool(Icons.auto_awesome, 'magicClean', _magicSheet),
            tool(Icons.draw, 'sign', _sign),
            tool(Icons.branding_watermark, 'watermark', _watermark),
            tool(Icons.library_add_check, 'applyAll', _applyAll),
            tool(Icons.text_snippet, 'ocr', _ocr),
            tool(Icons.cleaning_services, 'eraser', () {
              setState(() => _tool =
                  _tool == _Tool.eraser ? _Tool.none : _Tool.eraser);
            }, active: _tool == _Tool.eraser),
            tool(Icons.rotate_right, 'rotate', () {
              _push();
              setState(() => _rotation = (_rotation + 1) % 4);
              _rerender();
            }),
          ],
        ),
      ),
    ]);
  }
}

class _StrokePainter extends CustomPainter {
  _StrokePainter(this.strokes, this.size);
  final List<EraseStroke> strokes;
  final Size size;

  @override
  void paint(Canvas canvas, Size s) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final st in strokes) {
      paint.strokeWidth = st.width * s.width;
      final pts = st.points.map((e) => Offset(e.dx * s.width, e.dy * s.height)).toList();
      if (pts.length == 1) {
        canvas.drawCircle(pts.first, st.width * s.width / 2,
            Paint()..color = Colors.white);
      } else {
        final path = Path()..moveTo(pts.first.dx, pts.first.dy);
        for (final p in pts.skip(1)) {
          path.lineTo(p.dx, p.dy);
        }
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_StrokePainter old) => true;
}
