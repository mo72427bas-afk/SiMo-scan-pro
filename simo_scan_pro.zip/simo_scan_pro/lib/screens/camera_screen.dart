import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../imaging/geometry.dart';
import '../imaging/pipeline.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/library_service.dart';
import '../services/page_factory.dart';
import '../services/settings_service.dart';
import 'document_screen.dart';
import 'editor_screen.dart';

enum ScanMode { docs, id, book, batch }

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key, this.docId});

  /// When set, captured pages are appended to this document.
  final String? docId;

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  CameraController? _cam;
  bool _failed = false;
  ScanMode _mode = ScanMode.docs;
  FlashMode _flash = FlashMode.off;
  bool _grid = false;

  Quad? _live;
  int _misses = 0;
  bool _detecting = false;
  int _lastFrame = 0;

  String? _docId;
  int _count = 0;
  bool _busy = false;
  Uint8List? _idFront;

  @override
  void initState() {
    super.initState();
    _docId = widget.docId;
    WidgetsBinding.instance.addObserver(this);
    _initCamera();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cam?.dispose();
    super.dispose();
  }

  Future<CameraController> _open(CameraDescription d, ResolutionPreset p) async {
    final c = CameraController(
      d,
      p,
      enableAudio: false,
      imageFormatGroup:
          Platform.isAndroid ? ImageFormatGroup.yuv420 : ImageFormatGroup.bgra8888,
    );
    await c.initialize();
    return c;
  }

  Future<void> _focusAt(Offset p, Size s) async {
    final cam = _cam;
    if (cam == null) return;
    final pt = Offset((p.dx / s.width).clamp(0.0, 1.0), (p.dy / s.height).clamp(0.0, 1.0));
    try {
      await cam.setFocusPoint(pt);
      await cam.setExposurePoint(pt);
    } catch (_) {}
  }

  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      final back = cams.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cams.first);
      // Photos use the same resolution as this preset: use the highest that works.
      CameraController c;
      try {
        c = await _open(back, ResolutionPreset.ultraHigh);
      } catch (_) {
        c = await _open(back, ResolutionPreset.veryHigh);
      }
      try {
        await c.setFocusMode(FocusMode.auto);
        await c.setExposureMode(ExposureMode.auto);
      } catch (_) {}
      await c.setFlashMode(_flash);
      try {
        await c.lockCaptureOrientation(DeviceOrientation.portraitUp);
      } catch (_) {}
      if (!mounted) return;
      setState(() => _cam = c);
      await c.startImageStream(_onFrame);
    } catch (e) {
      debugPrint('camera init failed: $e');
      if (mounted) setState(() => _failed = true);
    }
  }

  // ---- live edge detection ---------------------------------------------
  void _onFrame(CameraImage img) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (_detecting || now - _lastFrame < 300) return;
    _detecting = true;
    _lastFrame = now;
    // Sample a small gray copy here (cheap) instead of copying a 4K plane.
    final plane = img.planes.first;
    final bgra = img.format.group == ImageFormatGroup.bgra8888;
    final px = bgra ? 4 : 1;
    final step = math.max(1, math.max(img.width, img.height) ~/ 320);
    final sw = img.width ~/ step, sh = img.height ~/ step;
    final small = Uint8List(sw * sh);
    final bytes = plane.bytes;
    for (var y = 0; y < sh; y++) {
      final row = y * step * plane.bytesPerRow + (bgra ? 1 : 0);
      for (var x = 0; x < sw; x++) {
        small[y * sw + x] = bytes[row + x * step * px];
      }
    }
    compute(liveDetectJob, {
      'bytes': small,
      'w': sw,
      'h': sh,
      'rowStride': sw,
      'pixelStride': 1,
      'offset': 0,
    }).then((r) {
      if (!mounted) return;
      if (r == null) {
        if (++_misses > 2 && _live != null) setState(() => _live = null);
      } else {
        _misses = 0;
        final q = _toPreview(Quad.fromList(r));
        setState(() => _live = _live == null ? q : _live!.lerp(q, .55));
      }
    }).whenComplete(() => _detecting = false);
  }

  /// Camera frames are in sensor orientation; rotate to the portrait preview.
  Quad _toPreview(Quad q) {
    final rot = _cam?.description.sensorOrientation ?? 90;
    Pt t(Pt p) => switch (rot) {
          90 => Pt(1 - p.y, p.x),
          270 => Pt(p.y, 1 - p.x),
          180 => Pt(1 - p.x, 1 - p.y),
          _ => p,
        };
    return Quad.fromUnordered(q.points.map(t).toList());
  }

  // ---- capture ------------------------------------------------------------
  Future<String> _ensureDoc() async {
    if (_docId != null) return _docId!;
    final lib = context.read<LibraryService>();
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final d = await lib.createDoc(
        'Scan ${now.year}-${two(now.month)}-${two(now.day)} ${two(now.hour)}:${two(now.minute)}');
    _docId = d.id;
    return d.id;
  }

  Future<void> _capture() async {
    final cam = _cam;
    if (cam == null || _busy) return;
    setState(() => _busy = true);
    try {
      await cam.stopImageStream();
      final shot = await cam.takePicture();
      final bytes = await shot.readAsBytes();
      await _handleImage(bytes);
    } catch (e) {
      debugPrint('capture failed: $e');
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        try {
          await cam.startImageStream(_onFrame);
        } catch (_) {}
      }
    }
  }

  Future<void> _handleImage(Uint8List bytes) async {
    final factory = context.read<PageFactory>();
    final lib = context.read<LibraryService>();
    final rtl = context.read<SettingsService>().bookRtl;
    switch (_mode) {
      case ScanMode.id:
        if (_idFront == null) {
          setState(() => _idFront = bytes);
          return;
        }
        final id = await _ensureDoc();
        final page = await factory.fromIdCard(id, _idFront!, bytes);
        await lib.addPages(id, [page]);
        setState(() {
          _idFront = null;
          _count += 1;
        });
      case ScanMode.book:
        final id = await _ensureDoc();
        final pages = await factory.fromBook(id, bytes, rtl: rtl);
        await lib.addPages(id, pages);
        setState(() => _count += pages.length);
      case ScanMode.docs:
      case ScanMode.batch:
        final id = await _ensureDoc();
        final PageModel page = await factory.fromImage(id, bytes);
        await lib.addPages(id, [page]);
        setState(() => _count += 1);
        if (_mode == ScanMode.docs && mounted) {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  EditorScreen(docId: id, pageId: page.id, startInCrop: true),
            ),
          );
        }
    }
  }

  Future<void> _importGallery() async {
    final files = await ImagePicker().pickMultiImage(imageQuality: 100);
    if (files.isEmpty) return;
    setState(() => _busy = true);
    try {
      final factory = context.read<PageFactory>();
      final lib = context.read<LibraryService>();
      final id = await _ensureDoc();
      for (final f in files) {
        final page = await factory.fromImage(id, await f.readAsBytes());
        await lib.addPages(id, [page]);
        _count++;
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    _finish();
  }

  void _finish() {
    final id = _docId;
    if (id == null || _count == 0) {
      Navigator.pop(context);
      return;
    }
    if (widget.docId != null) {
      Navigator.pop(context);
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => DocumentScreen(docId: id)));
    }
  }

  Future<void> _cycleFlash() async {
    final next = switch (_flash) {
      FlashMode.off => FlashMode.auto,
      FlashMode.auto => FlashMode.always,
      _ => FlashMode.off,
    };
    await _cam?.setFlashMode(next);
    setState(() => _flash = next);
  }

  // ---- UI -------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          _topBar(),
          Expanded(child: _preview()),
          _modeBar(),
          _bottomBar(),
        ]),
      ),
    );
  }

  Widget _topBar() {
    final flashIcon = switch (_flash) {
      FlashMode.off => Icons.flash_off,
      FlashMode.auto => Icons.flash_auto,
      _ => Icons.flash_on,
    };
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(children: [
        IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: _finish),
        const Spacer(),
        IconButton(
            icon: Icon(flashIcon, color: Colors.white), onPressed: _cycleFlash),
        IconButton(
          icon: Icon(Icons.grid_on, color: _grid ? AppColors.gold : Colors.white),
          onPressed: () => setState(() => _grid = !_grid),
        ),
      ]),
    );
  }

  Widget _preview() {
    if (_failed) {
      return Center(
          child: Text(context.tr('cameraError'),
              style: const TextStyle(color: Colors.white70)));
    }
    final cam = _cam;
    if (cam == null || !cam.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    final hint = switch (_mode) {
      ScanMode.id => context.tr(_idFront == null ? 'idFront' : 'idBack'),
      ScanMode.book => context.tr('bookHint'),
      _ => null,
    };
    return Center(
      child: AspectRatio(
        aspectRatio: 1 / cam.value.aspectRatio,
        child: LayoutBuilder(
          builder: (context, box) => GestureDetector(
            onTapDown: (d) =>
                _focusAt(d.localPosition, Size(box.maxWidth, box.maxHeight)),
            child: Stack(fit: StackFit.expand, children: [
          CameraPreview(cam),
          CustomPaint(painter: _OverlayPainter(_live, _grid, _mode)),
          if (hint != null)
            Positioned(
              left: 12,
              right: 12,
              top: 12,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.black54, borderRadius: BorderRadius.circular(10)),
                child: Text(hint,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white)),
              ),
            ),
          if (_busy)
            Container(
              color: Colors.black54,
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 12),
                  Text(context.tr('processing'),
                      style: const TextStyle(color: Colors.white)),
                ]),
              ),
            ),
        ]),
          ),
        ),
      ),
    );
  }

  Widget _modeBar() {
    Widget m(ScanMode mode, String key) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: GestureDetector(
            onTap: () => setState(() {
              _mode = mode;
              _idFront = null;
            }),
            child: Text(
              context.tr(key),
              style: TextStyle(
                color: _mode == mode ? AppColors.gold : Colors.white70,
                fontWeight: _mode == mode ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        m(ScanMode.docs, 'modeDocs'),
        m(ScanMode.id, 'modeId'),
        m(ScanMode.book, 'modeBook'),
        m(ScanMode.batch, 'modeBatch'),
      ]),
    );
  }

  Widget _bottomBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(
          iconSize: 30,
          icon: const Icon(Icons.photo_library, color: Colors.white),
          tooltip: context.tr('import'),
          onPressed: _busy ? null : _importGallery,
        ),
        GestureDetector(
          onTap: _capture,
          child: Container(
            width: 74,
            height: 74,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 4),
            ),
            padding: const EdgeInsets.all(5),
            child: Container(
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _busy ? Colors.grey : AppColors.gold),
            ),
          ),
        ),
        SizedBox(
          width: 48,
          child: _count == 0
              ? null
              : Badge(
                  label: Text('$_count'),
                  child: IconButton.filled(
                    icon: const Icon(Icons.collections),
                    onPressed: _busy ? null : _finish,
                  ),
                ),
        ),
      ]),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  _OverlayPainter(this.quad, this.grid, this.mode);
  final Quad? quad;
  final bool grid;
  final ScanMode mode;

  @override
  void paint(Canvas canvas, Size s) {
    if (grid) {
      final p = Paint()
        ..color = Colors.white30
        ..strokeWidth = 1;
      for (var i = 1; i < 3; i++) {
        canvas.drawLine(Offset(s.width * i / 3, 0), Offset(s.width * i / 3, s.height), p);
        canvas.drawLine(Offset(0, s.height * i / 3), Offset(s.width, s.height * i / 3), p);
      }
    }
    if (mode == ScanMode.id) {
      final w = s.width * .86, h = w / 1.586;
      final r = RRect.fromRectAndRadius(
          Rect.fromCenter(center: s.center(Offset.zero), width: w, height: h),
          const Radius.circular(14));
      canvas.drawRRect(
          r,
          Paint()
            ..color = Colors.white70
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
    } else if (mode == ScanMode.book) {
      canvas.drawLine(
          Offset(s.width / 2, s.height * .1),
          Offset(s.width / 2, s.height * .9),
          Paint()
            ..color = Colors.white54
            ..strokeWidth = 2);
    }
    final q = quad;
    if (q != null) {
      final path = Path()
        ..moveTo(q.tl.x * s.width, q.tl.y * s.height)
        ..lineTo(q.tr.x * s.width, q.tr.y * s.height)
        ..lineTo(q.br.x * s.width, q.br.y * s.height)
        ..lineTo(q.bl.x * s.width, q.bl.y * s.height)
        ..close();
      canvas.drawPath(path, Paint()..color = AppColors.blue.withValues(alpha: .22));
      canvas.drawPath(
          path,
          Paint()
            ..color = AppColors.gold
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3
            ..strokeJoin = StrokeJoin.round);
    }
  }

  @override
  bool shouldRepaint(_OverlayPainter old) =>
      old.quad != quad || old.grid != grid || old.mode != mode;
}
