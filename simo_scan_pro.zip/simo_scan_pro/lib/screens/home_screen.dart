import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/library_service.dart';
import '../services/settings_service.dart';
import 'camera_screen.dart';
import 'document_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _folderId; // null = root
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryService>();
    final settings = context.watch<SettingsService>();
    final isAr = Localizations.localeOf(context).languageCode == 'ar';
    final searching = _query.trim().isNotEmpty;

    final folders = searching
        ? <FolderModel>[]
        : lib.folders.where((f) => f.parentId == _folderId).toList();
    final docs = lib.docs.where((d) {
      if (searching) {
        return d.name.toLowerCase().contains(_query.trim().toLowerCase());
      }
      return d.folderId == _folderId;
    }).toList();

    final currentFolder = _folderId == null
        ? null
        : lib.folders.where((f) => f.id == _folderId).firstOrNull;

    return PopScope(
      canPop: _folderId == null,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _folderId = currentFolder?.parentId);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(currentFolder?.name ?? context.tr('app')),
          actions: [
            IconButton(
              icon: const Icon(Icons.create_new_folder_outlined),
              tooltip: context.tr('newFolder'),
              onPressed: () async {
                final n = await askText(context, context.tr('newFolder'));
                if (n != null && n.isNotEmpty) {
                  lib.createFolder(n, parentId: _folderId);
                }
              },
            ),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'lang') {
                  settings.setLocale(Locale(isAr ? 'en' : 'ar'));
                } else if (v == 'rtl') {
                  settings.setBookRtl(!settings.bookRtl);
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'lang', child: Text(context.tr('language'))),
                CheckedPopupMenuItem(
                  value: 'rtl',
                  checked: settings.bookRtl,
                  child: Text(isAr ? 'كتاب من اليمين لليسار' : 'Book: right-to-left'),
                ),
              ],
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(56),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: SearchBar(
                hintText: context.tr('search'),
                leading: const Icon(Icons.search),
                elevation: const WidgetStatePropertyAll(0),
                onChanged: (v) => setState(() => _query = v),
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.document_scanner),
          label: Text(context.tr('scan')),
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CameraScreen()),
            );
          },
        ),
        body: (folders.isEmpty && docs.isEmpty)
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(context.tr('empty'), textAlign: TextAlign.center),
                ),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
                children: [
                  for (final f in folders) _folderTile(context, lib, f),
                  for (final d in docs) _docTile(context, lib, d),
                ],
              ),
      ),
    );
  }

  Widget _folderTile(BuildContext context, LibraryService lib, FolderModel f) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.folder, size: 36),
        title: Text(f.name),
        onTap: () => setState(() => _folderId = f.id),
        trailing: PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'rename') {
              final n = await askText(context, context.tr('rename'), initial: f.name);
              if (n != null && n.isNotEmpty) lib.renameFolder(f.id, n);
            } else if (v == 'delete') {
              if (await confirm(context)) lib.deleteFolder(f.id);
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'rename', child: Text(context.tr('rename'))),
            PopupMenuItem(value: 'delete', child: Text(context.tr('delete'))),
          ],
        ),
      ),
    );
  }

  Widget _docTile(BuildContext context, LibraryService lib, DocModel d) {
    final first = d.pages.isEmpty ? null : d.pages.first;
    final date = d.created;
    String two(int v) => v.toString().padLeft(2, '0');
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(8),
        leading: SizedBox(
          width: 56,
          height: 72,
          child: first == null
              ? const Icon(Icons.description)
              : ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.file(
                    lib.fileOf(d.id, first.procFile),
                    fit: BoxFit.cover,
                    cacheWidth: 200,
                    errorBuilder: (_, __, ___) => const Icon(Icons.broken_image),
                  ),
                ),
        ),
        title: Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(
            '${d.pages.length} ${context.tr('pages')} · ${date.year}-${two(date.month)}-${two(date.day)}'),
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => DocumentScreen(docId: d.id))),
        trailing: PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'rename') {
              final n = await askText(context, context.tr('rename'), initial: d.name);
              if (n != null && n.isNotEmpty) lib.renameDoc(d.id, n);
            } else if (v == 'move') {
              _move(context, lib, d);
            } else if (v == 'delete') {
              if (await confirm(context)) lib.deleteDoc(d.id);
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'rename', child: Text(context.tr('rename'))),
            PopupMenuItem(value: 'move', child: Text(context.tr('moveTo'))),
            PopupMenuItem(value: 'delete', child: Text(context.tr('delete'))),
          ],
        ),
      ),
    );
  }

  void _move(BuildContext context, LibraryService lib, DocModel d) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
            leading: const Icon(Icons.home_outlined),
            title: Text(context.tr('root')),
            onTap: () {
              lib.moveDoc(d.id, null);
              Navigator.pop(ctx);
            },
          ),
          for (final f in lib.folders)
            ListTile(
              leading: const Icon(Icons.folder_outlined),
              title: Text(f.name),
              onTap: () {
                lib.moveDoc(d.id, f.id);
                Navigator.pop(ctx);
              },
            ),
        ]),
      ),
    );
  }
}
