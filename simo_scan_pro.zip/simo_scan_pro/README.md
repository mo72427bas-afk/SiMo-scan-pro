# SiMo Scan Pro

تطبيق Flutter لمسح المستندات (Android + iOS) بواجهة عربي/إنجليزي، كل الميزات مفتوحة بدون علامة مائية.
A full-featured document scanner built with Flutter. All features are unlocked, exports are always watermark-free.

## الميزات / Features

| الميزة | الحالة |
|---|---|
| كاميرا + كشف حواف مباشر (إطار أزرق/ذهبي)، فلاش، شبكة | ✅ |
| أوضاع: مستندات، بطاقة هوية (وجهين في A4)، كتاب (تقسيم صفحتين)، متعدد | ✅ (الكتاب: تقسيم + قص، بدون تعديل الانحناء) |
| استيراد من المعرض | ✅ |
| قص بـ 8 نقاط تحكم + عدسة مكبرة + Perspective Crop | ✅ |
| فلاتر: Magic Color HD، أبيض/أسود، رمادي، أصلي | ✅ |
| إزالة الظلال والبقع | ✅ (تطبيع الإضاءة) |
| إزالة الأصابع | ⚠️ تجريبي (كشف لون البشرة عند الحواف) |
| توقيع إلكتروني شفاف، علامة مائية نصية، ممحاة، تدوير | ✅ |
| OCR عربي + إنجليزي | ✅ Tesseract (`ara+eng`) |
| مكتبة: مجلدات، بحث، إعادة تسمية، نقل، ترتيب الصفحات | ✅ |
| تصدير PDF (3 جودات + كلمة مرور حقيقية) / JPG / TXT / DOCX، مع مشاركة (واتساب) وحفظ على الجهاز | ✅ |
| تراجع / إعادة في المحرر | ✅ |
| تسطيح انحناء السطور (كتاب) | ⚠️ تقريبي |

> ملاحظة: Google ML Kit **لا يدعم العربية** في التعرف على النص، لذلك استخدمنا Tesseract.

## التشغيل / Run

```bash
# يحتاج Flutter SDK (stable) + اتصال بالإنترنت
bash tool/bootstrap.sh     # ينشئ android/ و ios/، يضيف الصلاحيات، ينزّل ملفات OCR، ثم pub get
flutter run
```

بناء APK: `flutter build apk --release`. الـ CI (`.github/workflows/build.yml`) يعمل كل هذا تلقائياً ويرفع الـ APK كـ artifact.

## المعمارية / Architecture

```
lib/
  imaging/     معالجة الصور بلغة Dart صافية (تعمل داخل isolates)
    edge_detector.dart   Otsu + أكبر منطقة + أركان
    geometry.dart        Homography + Perspective warp
    filters.dart         تطبيع الإضاءة، Magic Color، B&W (adaptive threshold)، إزالة الأصابع
    pipeline.dart        مداخل الـ isolate (render/import/book/ID)
  services/    المكتبة، التصدير، OCR، دمج التوقيع/الممحاة
  screens/     home, camera, editor, document
  widgets/     crop_canvas, signature_pad
  l10n/        نصوص العربي/الإنجليزي
```

## حالة المشروع / Status

الكود كُتب بدون تشغيل Flutter SDK (لم يكن متاحاً)، فلم يُترجم ولم يُجرَّب على جهاز بعد.
أول بناء على الـ CI قد يُظهر أخطاء بسيطة تحتاج تصحيحاً، خصوصاً:
- تشفير الـ PDF مكتوب بخوارزمية مختبرة بـ qpdf في Python ومنقولة لـ Dart (لم تُشغَّل في Dart بعد).
- دقة كشف الحواف تحتاج ضبطاً على صور حقيقية.

## الترخيص / License
MIT
